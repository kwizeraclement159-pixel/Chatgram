"use strict";

// =====================================================
// CHATGRAM — C'S FAME
// Supabase Authentication, Profiles, Videos,
// Messages and Notifications
// =====================================================

const SUPABASE_URL = "https://wgmlhqfwvcyrkslarfra.supabase.co";

const SUPABASE_PUBLISHABLE_KEY =
  "sb_publishable_-6GYSlWtBvCffUSZQ7UlAw_FGY5z4a8";

const AVATAR_BUCKET = "avatars";
const VIDEO_BUCKET = "videos";
const MAX_VIDEO_SIZE = 50 * 1024 * 1024;
const MAX_AVATAR_SIZE = 5 * 1024 * 1024;

let supabaseClient = null;
let currentUser = null;
let currentProfile = null;
let currentPage = "home";

let activeConversationUser = null;
let activeConversationProfile = null;

let messageChannel = null;
let notificationChannel = null;
let activeObjectURL = null;
let notificationCount = 0;
let conversationRefreshTimer = null;

const $ = id => document.getElementById(id);

// =====================================================
// HELPERS
// =====================================================

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, character => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[character]);
}

function initials(name) {
  return String(name || "C")
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map(part => part[0] || "")
    .join("")
    .toUpperCase();
}

function displayName(profile = currentProfile) {
  return profile?.full_name ||
    currentUser?.user_metadata?.full_name ||
    currentUser?.email?.split("@")[0] ||
    "ChatGram User";
}

function toast(message) {
  const element = $("toast");

  if (!element) {
    console.log(message);
    return;
  }

  element.textContent = message;
  element.style.display = "block";

  clearTimeout(window.cgToastTimer);

  window.cgToastTimer = setTimeout(() => {
    element.style.display = "none";
  }, 3500);
}

function friendlyError(error) {
  console.error("ChatGram error:", error);

  if (!navigator.onLine) {
    return "You are offline. Connect to the internet and try again.";
  }

  const message = error?.message || "";

  if (/Invalid login credentials/i.test(message)) {
    return "Email or password is incorrect.";
  }

  if (/Email not confirmed/i.test(message)) {
    return "Please confirm your email before logging in.";
  }

  if (/row-level security|violates row-level security/i.test(message)) {
    return "Database permission denied. Check your Supabase RLS policies.";
  }

  if (/relation .* does not exist|could not find the table/i.test(message)) {
    return "A required database table is missing. Check your Supabase tables.";
  }

  if (/duplicate key/i.test(message)) {
    return "This record already exists.";
  }

  return message || "Something went wrong. Please try again.";
}

function formatDate(value) {
  if (!value) return "";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return "";

  return date.toLocaleString();
}



// ChatGram: cache profile photos for offline display
const CHATGRAM_AVATAR_CACHE = "chatgram_avatar_cache_v1";

function getCachedAvatar(url) {
  if (!url) return "";
  
  try {
    const cache = JSON.parse(
      localStorage.getItem(CHATGRAM_AVATAR_CACHE) || "{}"
    );
    
    return cache[url] || "";
  } catch (error) {
    console.warn("Could not read cached avatar:", error);
    return "";
  }
}

async function cacheAvatar(url) {
  if (!url || !navigator.onLine) return;
  
  try {
    const response = await fetch(url);
    
    if (!response.ok) return;
    
    const blob = await response.blob();
    
    // Avoid saving unexpectedly large images.
    if (blob.size > 2 * 1024 * 1024) return;
    
    const reader = new FileReader();
    
    reader.onload = () => {
      try {
        const cache = JSON.parse(
          localStorage.getItem(CHATGRAM_AVATAR_CACHE) || "{}"
        );
        
        cache[url] = reader.result;
        
        localStorage.setItem(
          CHATGRAM_AVATAR_CACHE,
          JSON.stringify(cache)
        );
      } catch (error) {
        console.warn("Avatar could not be cached:", error);
      }
    };
    
    reader.readAsDataURL(blob);
  } catch (error) {
    console.warn("Could not download avatar for offline use:", error);
  }
}

function safeAvatarHTML(profile, className = "") {
  const url = profile?.avatar_url;

  if (url) {
    return `
      <div class="avatar ${className}">
        <img
          src="${escapeHTML(url)}"
          alt="Profile photo"
          loading="lazy"
        >
      </div>
    `;
  }

  return `
    <div class="avatar ${className}">
      ${escapeHTML(initials(profile?.full_name))}
    </div>
  `;
}

function getStoragePath(file) {
  const extension = file.name.includes(".")
    ? file.name.split(".").pop().toLowerCase().replace(/[^a-z0-9]/g, "")
    : "bin";

  const randomId = crypto.randomUUID();

  return `${currentUser.id}/${randomId}.${extension || "bin"}`;
}

async function getStorageURL(bucket, path) {
  if (!path) return null;

  // Works with both private and public buckets.
  const { data, error } = await supabaseClient.storage
    .from(bucket)
    .createSignedUrl(path, 3600);

  if (!error && data?.signedUrl) {
    return data.signedUrl;
  }

  const { data: publicData } = supabaseClient.storage
    .from(bucket)
    .getPublicUrl(path);

  return publicData?.publicUrl || null;
}

function setButtonLoading(button, loading, label = "Please wait...") {
  if (!button) return;

  if (loading) {
    button.dataset.originalText = button.textContent;
    button.disabled = true;
    button.textContent = label;
  } else {
    button.disabled = false;

    if (button.dataset.originalText) {
      button.textContent = button.dataset.originalText;
      delete button.dataset.originalText;
    }
  }
}

// =====================================================
// AUTHENTICATION
// =====================================================

function renderAuth(mode = "signup") {
  currentPage = "auth";

  $("app").innerHTML = `
    <section class="auth-screen">
      <div class="auth-card">
        <div class="auth-heading">
          <div class="auth-logo">C</div>
          <h1>ChatGram</h1>
          <p class="muted">C's Fame — Connect with your people.</p>
        </div>

        <div class="auth-tabs">
          <button
            type="button"
            id="signupTab"
            class="${mode === "signup" ? "selected" : ""}">
            Create account
          </button>

          <button
            type="button"
            id="loginTab"
            class="${mode === "login" ? "selected" : ""}">
            Log in
          </button>
        </div>

        <form id="authForm" class="auth-form">
          <div id="nameField" class="${mode === "login" ? "hidden" : ""}">
            <label for="fullName">Full name</label>
            <input
              id="fullName"
              type="text"
              maxlength="80"
              autocomplete="name"
              placeholder="Your full name"
              ${mode === "signup" ? "required" : ""}>
          </div>

          <div>
            <label for="email">Email address</label>
            <input
              id="email"
              type="email"
              autocomplete="email"
              placeholder="you@example.com"
              required>
          </div>

          <div>
            <label for="password">Password</label>
            <input
              id="password"
              type="password"
              minlength="8"
              autocomplete="${mode === "signup" ? "new-password" : "current-password"}"
              placeholder="At least 8 characters"
              required>
          </div>

          <button
            id="authSubmit"
            class="primary-button full-width"
            type="submit">
            ${mode === "signup" ? "Create account" : "Log in"}
          </button>

          <p id="authMessage" class="auth-message muted" aria-live="polite"></p>
        </form>
      </div>
    </section>
  `;

  $("signupTab").onclick = () => renderAuth("signup");
  $("loginTab").onclick = () => renderAuth("login");

  $("authForm").onsubmit = async event => {
    event.preventDefault();

    const button = $("authSubmit");
    const message = $("authMessage");

    setButtonLoading(button, true);
    message.textContent = "Connecting...";

    const email = $("email").value.trim();
    const password = $("password").value;
    const fullName = $("fullName").value.trim();

    try {
      if (mode === "signup") {
        if (!fullName) {
          throw new Error("Enter your full name.");
        }

        const { data, error } = await supabaseClient.auth.signUp({
          email,
          password,
          options: {
            data: { full_name: fullName }
          }
        });

        if (error) throw error;

        if (data.session && data.user) {
          currentUser = data.user;
          await enterApp();
        } else {
          message.textContent =
            "Account created. Check your email to confirm it, then log in.";
        }
      } else {
        const { data, error } = await supabaseClient.auth.signInWithPassword({
          email,
          password
        });

        if (error) throw error;

        currentUser = data.user;
        await enterApp();
      }
    } catch (error) {
      message.textContent = friendlyError(error);
    } finally {
      const submitButton = $("authSubmit");

      if (submitButton) {
        submitButton.disabled = false;
        submitButton.textContent =
          mode === "signup" ? "Create account" : "Log in";
      }
    }
  };
}

// =====================================================
// PROFILE
// =====================================================

async function loadProfile() {
  const cacheKey = currentUser
    ? `chatgram_profile_${currentUser.id}`
    : null;

  // 1. Try loading the profile from Supabase.
  try {
    const { data, error } = await supabaseClient
      .from("profiles")
      .select("id,full_name,bio,avatar_url,updated_at")
      .eq("id", currentUser.id)
      .maybeSingle();

    if (error) throw error;

    if (data) {
      currentProfile = data;

      // Save a copy for offline display.
      try {
        localStorage.setItem(cacheKey, JSON.stringify(data));
      } catch (cacheError) {
        console.warn("Profile cache unavailable:", cacheError);
      }

      return data;
    }

    // 2. Create a profile if none exists.
    const initialProfile = {
      id: currentUser.id,
      full_name:
        currentUser.user_metadata?.full_name ||
        currentUser.email?.split("@")[0] ||
        "ChatGram User",
      bio: "",
      avatar_url: null
    };

    const { data: created, error: createError } =
      await supabaseClient
        .from("profiles")
        .upsert(initialProfile, { onConflict: "id" })
        .select()
        .single();

    if (createError) throw createError;

    currentProfile = created;

    try {
      localStorage.setItem(cacheKey, JSON.stringify(created));
    } catch (cacheError) {
      console.warn("Profile cache unavailable:", cacheError);
    }

    return created;

  } catch (error) {
    console.warn("Could not load profile from Supabase:", error);

    // 3. Fall back to this user's previously saved profile.
    if (cacheKey) {
      try {
        const saved = localStorage.getItem(cacheKey);

        if (saved) {
          const profile = JSON.parse(saved);

          // Do not use a cached profile belonging to another user.
          if (profile.id === currentUser.id) {
            currentProfile = profile;
            return profile;
          }
        }
      } catch (cacheError) {
        console.warn("Could not read cached profile:", cacheError);
      }
    }

    // No cached profile exists.
    throw error;
  }
}
async function saveProfile(event) {
  event.preventDefault();

  const button = $("saveProfile");
  setButtonLoading(button, true, "Saving...");

  let uploadedPath = null;

  try {
    const fullName = $("profileName").value.trim();
    const bio = $("profileBioInput").value.trim();
    const avatarFile = $("avatarFile").files[0];

    if (!fullName) {
      throw new Error("Enter your full name.");
    }

    // Store the STORAGE PATH in the database, not the temporary URL.
    let avatarPath = currentProfile?.avatar_url || null;

    if (avatarFile) {
      if (!["image/jpeg", "image/png", "image/webp"].includes(avatarFile.type)) {
        throw new Error("Choose a JPG, PNG or WebP image.");
      }

      if (avatarFile.size > MAX_AVATAR_SIZE) {
        throw new Error("Profile photo must be 5 MB or smaller.");
      }

      uploadedPath = getStoragePath(avatarFile);

      const { error: uploadError } = await supabaseClient.storage
        .from(AVATAR_BUCKET)
        .upload(uploadedPath, avatarFile, {
          contentType: avatarFile.type,
          upsert: false
        });

      if (uploadError) throw uploadError;

      avatarPath = uploadedPath;
    }

    const { data, error } = await supabaseClient
      .from("profiles")
      .upsert({
        id: currentUser.id,
        full_name: fullName,
        bio,
        avatar_url: avatarPath,
        updated_at: new Date().toISOString()
      }, { onConflict: "id" })
      .select()
      .single();

    if (error) throw error;

    currentProfile = data;

    if (avatarPath) {
      currentProfile = {
        ...data,
        avatar_url: await getStorageURL(AVATAR_BUCKET, avatarPath)
      };
    }

    toast("Profile saved successfully.");
    await renderShell();
    openPage("profile");
  } catch (error) {
    if (uploadedPath) {
      await supabaseClient.storage
        .from(AVATAR_BUCKET)
        .remove([uploadedPath])
        .catch(() => {});
    }

    toast(friendlyError(error));
  } finally {
    if ($("saveProfile")) {
      $("saveProfile").disabled = false;
      $("saveProfile").textContent = "Save profile";
    }
  }
}

async function refreshOwnProfile() {
  try {
    const profile = await loadProfile();

    // Keep the database path separate from the display URL.
    const displayProfile = {
      ...profile,
      avatar_url: profile.avatar_url
        ? await getStorageURL(AVATAR_BUCKET, profile.avatar_url)
        : null
    };

    if ($("profilePreview")) {
      $("profilePreview").innerHTML =
        safeAvatarHTML(displayProfile, "large");
    }

    if ($("profileDisplayName")) {
      $("profileDisplayName").textContent = profile.full_name || "ChatGram User";
    }

    if ($("profileBio")) {
      $("profileBio").textContent = profile.bio || "Add a bio to introduce yourself.";
    }
  } catch (error) {
    console.error("Profile refresh failed:", error);
  }
}

function previewAvatar() {
  const file = $("avatarFile")?.files?.[0];

  if (!file) return;

  if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
    toast("Choose a JPG, PNG or WebP image.");
    $("avatarFile").value = "";
    return;
  }

  if (file.size > MAX_AVATAR_SIZE) {
    toast("Profile photo must be 5 MB or smaller.");
    $("avatarFile").value = "";
    return;
  }

  if (activeObjectURL) {
    URL.revokeObjectURL(activeObjectURL);
  }

  activeObjectURL = URL.createObjectURL(file);

  $("avatarPreviewNote").innerHTML = `
    <img class="preview-image" src="${activeObjectURL}" alt="Photo preview">
  `;
}

// =====================================================
// APP LAYOUT
// =====================================================

async function renderShell() {
  $("app").innerHTML = `
    <div class="app-layout">
      <header class="topbar">
        <div class="brand">
          <div class="logo">C</div>
          <div>
            <h1>ChatGram</h1>
            <p>C's Fame</p>
          </div>
        </div>

        <div class="topbar-actions">
          <button
            type="button"
            class="icon-button notification-button"
            id="headerNotifications"
            aria-label="Notifications">
            🔔
            <span id="notificationBadge" class="notification-badge hidden">0</span>
          </button>

          <button
            type="button"
            class="icon-button"
            id="headerProfile"
            aria-label="My profile">
            👤
          </button>
        </div>
      </header>

      <main class="main-content">

        <section id="page-home" class="app-page">
          <div class="page-heading">
            <p class="muted">WELCOME TO YOUR WORLD</p>
            <h2>Connect with your people.</h2>
            <p>Your conversations, your memories, your world.</p>
          </div>

          

          <div class="card">
            <h3>💬 Messages</h3>
            <p class="muted">Send private messages to other ChatGram users.</p>
            <button type="button" class="primary-button" data-go="messages">
              Open messages
            </button>
          </div>

          <div class="card">
            <h3>🔔 Notifications</h3>
            <p class="muted">See new messages and account updates.</p>
            <button type="button" class="secondary-button" data-go="notifications">
              View notifications
            </button>
          </div>

          <div class="card">
            <h3>🎬 C's Fame Videos</h3>
            <p class="muted">Share your creativity with your community.</p>
            <button type="button" class="primary-button" data-go="videos">
              Open video feed
            </button>
          </div>
        </section>

        <section id="page-profile" class="app-page hidden">
          <div class="page-heading">
            <h2>My Profile</h2>
            <p>Manage how people see you.</p>
          </div>

          <div class="card profile-cover">
            <div id="profilePreview">
              ${safeAvatarHTML(currentProfile, "large")}
            </div>

            <h2 id="profileDisplayName">
              ${escapeHTML(displayName())}
            </h2>

            <p class="muted">${escapeHTML(currentUser.email || "")}</p>

            <p id="profileBio" class="profile-bio">
              ${escapeHTML(currentProfile?.bio || "Add a bio to introduce yourself.")}
            </p>
          </div>

          <form id="profileForm" class="card form-grid">
            <h3>Edit profile</h3>

            <label for="profileName">Full name</label>
            <input
              id="profileName"
              maxlength="80"
              required
              value="${escapeHTML(currentProfile?.full_name || "")}">

            <label for="profileBioInput">Bio</label>
            <textarea
              id="profileBioInput"
              maxlength="300"
              placeholder="Tell people about yourself">${escapeHTML(currentProfile?.bio || "")}</textarea>

            <label class="file-label">
              Choose profile photo
              <input
                id="avatarFile"
                type="file"
                accept="image/jpeg,image/png,image/webp">
            </label>

            <div id="avatarPreviewNote" class="muted">
              JPG, PNG or WebP. Maximum 5 MB.
            </div>

            <button id="saveProfile" class="primary-button" type="submit">
              Save profile
            </button>
          </form>
        </section>

        <section id="page-people" class="app-page hidden">
          <div class="page-heading">
            <h2>Find People</h2>
            <p>Search for ChatGram users and start conversations.</p>
          </div>

          <form id="peopleSearchForm" class="search-form">
            <input
              id="peopleQuery"
              type="search"
              maxlength="80"
              placeholder="Search by name..."
              required>
            <button class="primary-button" type="submit">Search</button>
          </form>

          <div id="peopleResults" class="card">
            Search for someone to get started.
          </div>
        </section>

        <section id="page-messages" class="app-page hidden">
          <div class="page-heading">
            <h2>Messages 💬</h2>
            <p>Your private ChatGram conversations.</p>
          </div>

          <form id="messagePeopleForm" class="search-form">
            <input
              id="messagePeopleQuery"
              type="search"
              maxlength="80"
              placeholder="Find someone to message..."
              required>
            <button class="primary-button" type="submit">Find</button>
          </form>

          <div id="messagePeopleResults" class="card hidden"></div>

          <div id="conversationListCard" class="card">
            <h3>Your conversations</h3>
            <div id="conversationList" class="conversation-list">
              Loading conversations...
            </div>
          </div>

          <div id="chatWindow" class="card hidden">
            <div class="conversation-header">
              <div id="chatAvatar"></div>
              <div class="person-info">
                <strong id="chatPersonName">Conversation</strong>
                <p id="chatStatus" class="muted">ChatGram messages</p>
              </div>
              <button type="button" id="closeChat" class="secondary-button">
                Back
              </button>
            </div>

            <div id="chatMessages" class="chat-messages" aria-live="polite">
              Loading messages...
            </div>

            <form id="sendMessageForm" class="message-compose">
              <textarea
                id="messageText"
                maxlength="5000"
                rows="1"
                placeholder="Write a message..."
                required></textarea>

              <button type="submit" class="primary-button" id="sendMessageButton">
                Send
              </button>
            </form>
          </div>
        </section>

        <section id="page-notifications" class="app-page hidden">
          <div class="page-heading">
            <h2>Notifications 🔔</h2>
            <p>Stay updated on your conversations.</p>
          </div>

          <button
            type="button"
            id="markAllNotificationsRead"
            class="secondary-button">
            Mark all as read
          </button>

          <div id="notificationsList" class="card" style="margin-top:15px">
            Loading notifications...
          </div>
        </section>

        <section id="page-videos" class="app-page hidden">
          <div class="page-heading">
            <h2>C's Fame Videos</h2>
            <p>Share and watch videos from your community.</p>
          </div>

          <form id="videoForm" class="card form-grid">
            <h3>Share a video</h3>

            <label for="videoCaption">Caption</label>
            <textarea
              id="videoCaption"
              maxlength="1000"
              placeholder="Write something about your video..."></textarea>

            <label class="file-label">
              Choose video
              <input
                id="videoFile"
                type="file"
                accept="video/*"
                required>
            </label>

            <p id="videoFileInfo" class="muted">
              Maximum video size: 50 MB.
            </p>

            <button type="submit" class="primary-button" id="publishVideo">
              Publish video
            </button>
          </form>

          <div id="videoFeed" class="video-feed">
            <div class="card empty-state">Open Videos to load the feed.</div>
          </div>
        </section>

        <section id="page-settings" class="app-page hidden">
          <div class="page-heading">
            <h2>Settings</h2>
            <p>Manage your ChatGram preferences.</p>
          </div>

          <div class="card">
            <button type="button" class="settings-row" id="themeToggle">
              <span>🌙</span>
              <span>
                <strong>Dark mode</strong>
                <small>Change appearance on this device.</small>
              </span>
              <span id="themeState">Off</span>
            </button>

            <button type="button" class="settings-row" id="settingsProfile">
              <span>👤</span>
              <span>
                <strong>My profile</strong>
                <small>Edit your name, photo and bio.</small>
              </span>
            </button>

            <button type="button" class="settings-row" id="logoutButton">
              <span>↪</span>
              <span>
                <strong>Log out</strong>
                <small>Sign out of ChatGram.</small>
              </span>
            </button>
          </div>

          <div class="card">
            <strong>Signed in as</strong>
            <p>${escapeHTML(currentUser.email || "")}</p>
            <p class="muted">Authentication is managed by Supabase.</p>
          </div>
        </section>

      </main>

      <nav class="bottom-nav" aria-label="Main navigation">
        <button type="button" class="nav-item active" data-go="home">
          <span>⌂</span><small>Home</small>
        </button>

        <button type="button" class="nav-item" data-go="people">
          <span>👥</span><small>People</small>
        </button>

        <button type="button" class="nav-item" data-go="messages">
          <span>💬</span><small>Messages</small>
        </button>

        <button type="button" class="nav-item" data-go="notifications">
          <span>🔔</span><small>Alerts</small>
        </button>

        <button type="button" class="nav-item" data-go="videos">
          <span>▷</span><small>Videos</small>
        </button>

        <button type="button" class="nav-item" data-go="settings">
          <span>⚙</span><small>Settings</small>
        </button>
      </nav>
    </div>
  `;

  document.querySelectorAll("[data-go]").forEach(button => {
    button.addEventListener("click", () => openPage(button.dataset.go));
  });

  $("headerProfile").onclick = () => openPage("profile");
  $("headerNotifications").onclick = () => openPage("notifications");
  $("settingsProfile").onclick = () => openPage("profile");
  $("themeToggle").onclick = toggleTheme;
  $("logoutButton").onclick = logout;

  $("profileForm").onsubmit = saveProfile;
  $("avatarFile").onchange = previewAvatar;
  $("videoForm").onsubmit = publishVideo;
  $("peopleSearchForm").onsubmit = searchPeople;
  $("messagePeopleForm").onsubmit = searchMessagePeople;
  $("sendMessageForm").onsubmit = sendMessage;
  $("closeChat").onclick = closeConversation;
  $("markAllNotificationsRead").onclick = markAllNotificationsRead;

  $("videoFile").onchange = () => {
    const file = $("videoFile").files[0];

    $("videoFileInfo").textContent = file
      ? `${file.name} — ${(file.size / 1024 / 1024).toFixed(1)} MB`
      : "Maximum video size: 50 MB.";
  };

restoreTheme();
updateNotificationBadge();

if (navigator.onLine) {
  saveChatGramHomePage();
}
}

// ChatGram offline Home Page cache
const CHATGRAM_HOME_CACHE = "chatgram_home_cache_v1";

function saveChatGramHomePage() {
  const home = document.getElementById("page-home");
  
  if (!home) return;
  
  try {
    localStorage.setItem(
      CHATGRAM_HOME_CACHE,
      home.innerHTML
    );
  } catch (error) {
    console.warn("Could not save offline Home Page:", error);
  }
}

function showChatGramOfflineHome() {
  const app = document.getElementById("app");
  
  if (!app) return;
  
  let savedHome = null;
  
  try {
    savedHome = localStorage.getItem(CHATGRAM_HOME_CACHE);
  } catch (error) {
    console.warn("Could not read offline Home Page:", error);
  }
  
  app.innerHTML = `
    <div class="app-layout">
      <header class="topbar">
        <div class="brand">
          <div class="logo">C</div>
          <div>
            <h1>ChatGram</h1>
            <p>C's Fame</p>
          </div>
        </div>
      </header>

      <main class="main-content">
        <div class="card">
          <h2>Welcome to ChatGram</h2>
          <p class="muted">
            You are offline. Some features need an internet connection.
          </p>
          <p id="offlineHomeNotice" class="muted">
            ${savedHome
              ? "Your saved Home Page is available on this device."
              : "Your Home Page has not been saved on this device yet."}
          </p>
          <button
            type="button"
            class="primary-button"
            onclick="location.reload()">
            Try connecting again
          </button>
        </div>

        ${savedHome ? `
          <section class="card">
            <h3>Previously saved Home Page</h3>
            <div id="savedChatGramHome"></div>
          </section>
        ` : ""}
      </main>
    </div>
  `;
  
  if (savedHome) {
    const savedContainer = document.getElementById("savedChatGramHome");
    
    if (savedContainer) {
      savedContainer.innerHTML = savedHome;
    }
  }
}



function openPage(page) {
  const target = $(`page-${page}`);

  if (!target) return;

  currentPage = page;

  document.querySelectorAll(".app-page").forEach(section => {
    section.classList.add("hidden");
  });

  target.classList.remove("hidden");

  document.querySelectorAll("[data-go]").forEach(button => {
    button.classList.toggle("active", button.dataset.go === page);
  });

  window.scrollTo({ top: 0, behavior: "smooth" });

  if (page === "profile") refreshOwnProfile();
  if (page === "people") $("peopleQuery")?.focus();
  if (page === "messages") loadConversations();
  if (page === "notifications") loadNotifications();
  if (page === "videos") loadVideos();
}

// =====================================================
// PEOPLE DIRECTORY
// =====================================================

async function findProfiles(query) {
  const safeQuery = query.replace(/[%_,]/g, " ").trim();

  if (safeQuery.length < 2) {
    throw new Error("Enter at least two characters.");
  }

  const { data, error } = await supabaseClient
    .from("profiles")
    .select("id,full_name,bio,avatar_url")
    .ilike("full_name", `%${safeQuery}%`)
    .neq("id", currentUser.id)
    .limit(30);

  if (error) throw error;

  return data || [];
}

async function renderPeopleResults(profiles, container) {
  if (!profiles.length) {
    container.innerHTML = `
      <div class="empty-state">
        <h3>No profiles found</h3>
        <p>Try searching for another name.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = `
    ${profiles.map(profile => `
      <div class="person-result">
        <div class="avatar">${escapeHTML(initials(profile.full_name))}</div>

        <div class="person-info">
          <strong>${escapeHTML(profile.full_name || "ChatGram User")}</strong>
          <p>${escapeHTML(profile.bio || "ChatGram member")}</p>
        </div>

        <button
          type="button"
          class="secondary-button"
          data-message-person="${escapeHTML(profile.id)}">
          Message
        </button>
      </div>
    `).join("")}
  `;

  container.querySelectorAll("[data-message-person]").forEach(button => {
    button.onclick = () => openConversation(button.dataset.messagePerson);
  });
}

async function searchPeople(event) {
  event.preventDefault();

  const query = $("peopleQuery").value.trim();
  const results = $("peopleResults");

  results.textContent = "Searching...";

  try {
    const profiles = await findProfiles(query);
    await renderPeopleResults(profiles, results);
  } catch (error) {
    results.textContent = friendlyError(error);
  }
}

async function searchMessagePeople(event) {
  event.preventDefault();

  const query = $("messagePeopleQuery").value.trim();
  const results = $("messagePeopleResults");

  results.classList.remove("hidden");
  results.textContent = "Searching...";

  try {
    const profiles = await findProfiles(query);
    await renderPeopleResults(profiles, results);
  } catch (error) {
    results.textContent = friendlyError(error);
  }
}

// =====================================================
// MESSAGES
// =====================================================

async function openConversation(userId) {
  if (!userId || userId === currentUser.id) {
    toast("You cannot message your own account.");
    return;
  }

  try {
    const { data: profile, error } = await supabaseClient
      .from("profiles")
      .select("id,full_name,bio,avatar_url")
      .eq("id", userId)
      .single();

    if (error) throw error;

    activeConversationUser = userId;
    activeConversationProfile = profile;

    $("chatPersonName").textContent = profile.full_name || "ChatGram User";
    $("chatAvatar").innerHTML = safeAvatarHTML(profile);
    $("chatWindow").classList.remove("hidden");
    $("conversationListCard").classList.add("hidden");
    $("messagePeopleResults").classList.add("hidden");

    await loadConversationMessages();
    subscribeToConversation();

    openPage("messages");
    $("chatWindow").classList.remove("hidden");
    $("conversationListCard").classList.add("hidden");
  } catch (error) {
    toast(friendlyError(error));
  }
}

function closeConversation() {
  activeConversationUser = null;
  activeConversationProfile = null;

  if (messageChannel) {
    supabaseClient.removeChannel(messageChannel);
    messageChannel = null;
  }

  $("chatWindow")?.classList.add("hidden");
  $("conversationListCard")?.classList.remove("hidden");

  loadConversations();
}

async function loadConversationMessages() {
  if (!activeConversationUser || !$("chatMessages")) return;

  const otherUserId = activeConversationUser;

  $("chatMessages").innerHTML =
    `<p class="muted">Loading messages...</p>`;

  try {
    const { data, error } = await supabaseClient
      .from("messages")
      .select("id,sender_id,receiver_id,message_text,is_read,created_at")
      .or(
        `and(sender_id.eq.${currentUser.id},receiver_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},receiver_id.eq.${currentUser.id})`
      )
      .order("created_at", { ascending: true })
      .limit(200);

    if (error) throw error;

    // Ignore an old request if the user switched conversations.
    if (activeConversationUser !== otherUserId) return;

    renderConversationMessages(data || []);

    // Mark messages from the other person as read.
    const unreadIds = (data || [])
      .filter(message =>
        message.receiver_id === currentUser.id &&
        message.sender_id === otherUserId &&
        !message.is_read
      )
      .map(message => message.id);

    if (unreadIds.length) {
      const { error: readError } = await supabaseClient
        .from("messages")
        .update({ is_read: true })
        .in("id", unreadIds)
        .eq("receiver_id", currentUser.id);

      if (readError) {
        console.warn("Could not mark messages as read:", readError);
      }
    }
  } catch (error) {
    $("chatMessages").innerHTML = `
      <p class="muted">${escapeHTML(friendlyError(error))}</p>
    `;
  }
}

function renderConversationMessages(messages) {
  const container = $("chatMessages");

  if (!container) return;

  if (!messages.length) {
    container.innerHTML = `
      <div class="empty-state">
        <p>No messages yet. Say hello!</p>
      </div>
    `;
    return;
  }

  container.innerHTML = messages.map(message => {
    const mine = message.sender_id === currentUser.id;

    return `
      <div class="message-bubble ${mine ? "mine" : "theirs"}">
        <div>${escapeHTML(message.message_text)}</div>
        <div class="message-time">
          ${escapeHTML(formatDate(message.created_at))}
          ${mine ? (message.is_read ? " · Read" : " · Sent") : ""}
        </div>
      </div>
    `;
  }).join("");

  container.scrollTop = container.scrollHeight;
}

async function sendMessage(event) {
  event.preventDefault();

  if (!activeConversationUser) {
    toast("Choose a person before sending a message.");
    return;
  }

  const input = $("messageText");
  const button = $("sendMessageButton");
  const messageText = input.value.trim();

  if (!messageText) return;

  if (messageText.length > 5000) {
    toast("Message is too long.");
    return;
  }

  const receiverId = activeConversationUser;

  setButtonLoading(button, true, "Sending...");

  try {
    const { error } = await supabaseClient
      .from("messages")
      .insert({
        sender_id: currentUser.id,
        receiver_id: receiverId,
        message_text: messageText
      });

    if (error) throw error;

    input.value = "";

    await loadConversationMessages();
    await loadConversations();
  } catch (error) {
    toast(friendlyError(error));
  } finally {
    if ($("sendMessageButton")) {
      $("sendMessageButton").disabled = false;
      $("sendMessageButton").textContent = "Send";
    }
  }
}

function subscribeToConversation() {
  if (messageChannel) {
    supabaseClient.removeChannel(messageChannel);
    messageChannel = null;
  }

  if (!activeConversationUser) return;

  const otherUserId = activeConversationUser;

  messageChannel = supabaseClient
    .channel(`chat-${currentUser.id}-${otherUserId}`)
    .on(
      "postgres_changes",
      {
        event: "INSERT",
        schema: "public",
        table: "messages",
        filter: `receiver_id=eq.${currentUser.id}`
      },
      payload => {
        if (
          payload.new.sender_id === activeConversationUser
        ) {
          loadConversationMessages();
        }
      }
    )
    .on(
      "postgres_changes",
      {
        event: "INSERT",
        schema: "public",
        table: "messages",
        filter: `sender_id=eq.${currentUser.id}`
      },
      payload => {
        if (
          payload.new.receiver_id === activeConversationUser
        ) {
          loadConversationMessages();
        }
      }
    )
    .subscribe();
}

async function loadConversations() {
  const container = $("conversationList");

  if (!container || !currentUser) return;

  container.innerHTML = `<p class="muted">Loading conversations...</p>`;

  try {
    // Fetch messages involving the current user.
    const { data: messages, error } = await supabaseClient
      .from("messages")
      .select("id,sender_id,receiver_id,message_text,is_read,created_at")
      .or(
        `sender_id.eq.${currentUser.id},receiver_id.eq.${currentUser.id}`
      )
      .order("created_at", { ascending: false })
      .limit(200);

    if (error) throw error;

    const latestByUser = new Map();

    for (const message of messages || []) {
      const otherUserId = message.sender_id === currentUser.id
        ? message.receiver_id
        : message.sender_id;

      if (!latestByUser.has(otherUserId)) {
        latestByUser.set(otherUserId, message);
      }
    }

    if (!latestByUser.size) {
      container.innerHTML = `
        <div class="empty-state">
          <h3>No conversations yet</h3>
          <p>Search for someone above to start chatting.</p>
        </div>
      `;
      return;
    }

    const userIds = [...latestByUser.keys()];

    const { data: profiles, error: profileError } = await supabaseClient
      .from("profiles")
      .select("id,full_name,bio,avatar_url")
      .in("id", userIds);

    if (profileError) throw profileError;

    const profileMap = new Map(
      (profiles || []).map(profile => [profile.id, profile])
    );

    container.innerHTML = userIds.map(userId => {
      const message = latestByUser.get(userId);
      const profile = profileMap.get(userId) || {
        full_name: "ChatGram User"
      };

      const unread = message.receiver_id === currentUser.id &&
        !message.is_read;

      return `
        <button
          type="button"
          class="conversation-item"
          data-open-conversation="${escapeHTML(userId)}">

          ${safeAvatarHTML(profile)}

          <div class="person-info">
            <strong>${escapeHTML(profile.full_name)}</strong>
            <p>${escapeHTML(message.message_text)}</p>
            <small class="muted">${escapeHTML(formatDate(message.created_at))}</small>
          </div>

          ${unread ? '<span class="unread-dot" aria-label="Unread"></span>' : ""}
        </button>
      `;
    }).join("");

    container.querySelectorAll("[data-open-conversation]").forEach(button => {
      button.onclick = () => openConversation(button.dataset.openConversation);
    });
  } catch (error) {
    container.innerHTML = `
      <p>${escapeHTML(friendlyError(error))}</p>
    `;
  }
}

// =====================================================
// NOTIFICATIONS
// =====================================================

function updateNotificationBadge() {
  const badge = $("notificationBadge");

  if (!badge) return;

  if (notificationCount > 0) {
    badge.textContent = notificationCount > 99 ? "99+" : String(notificationCount);
    badge.classList.remove("hidden");
  } else {
    badge.classList.add("hidden");
  }
}

async function loadNotifications() {
  const container = $("notificationsList");

  if (!container || !currentUser) return;

  container.innerHTML = `<p class="muted">Loading notifications...</p>`;

  try {
    const { data, error } = await supabaseClient
      .from("notifications")
      .select("id,user_id,title,body,type,is_read,created_at")
      .eq("user_id", currentUser.id)
      .order("created_at", { ascending: false })
      .limit(100);

    if (error) throw error;

    notificationCount = (data || []).filter(item => !item.is_read).length;
    updateNotificationBadge();

    if (!data?.length) {
      container.innerHTML = `
        <div class="empty-state">
          <h3>You're all caught up!</h3>
          <p>Your notifications will appear here.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = data.map(item => `
      <article class="notification-item ${item.is_read ? "" : "unread"}">
        <div class="notification-icon">
          ${item.type === "message" ? "💬" : "🔔"}
        </div>

        <div class="notification-content">
          <strong>${escapeHTML(item.title || "Notification")}</strong>
          <p>${escapeHTML(item.body || "")}</p>
          <small>${escapeHTML(formatDate(item.created_at))}</small>

          ${!item.is_read ? `
            <div style="margin-top:8px">
              <button
                type="button"
                class="secondary-button"
                data-read-notification="${escapeHTML(item.id)}">
                Mark as read
              </button>
            </div>
          ` : ""}
        </div>
      </article>
    `).join("");

    container.querySelectorAll("[data-read-notification]").forEach(button => {
      button.onclick = () => markNotificationRead(button.dataset.readNotification);
    });
  } catch (error) {
    container.innerHTML = `
      <p>${escapeHTML(friendlyError(error))}</p>
    `;
  }
}

async function markNotificationRead(notificationId) {
  try {
    const { error } = await supabaseClient
      .from("notifications")
      .update({ is_read: true })
      .eq("id", notificationId)
      .eq("user_id", currentUser.id);

    if (error) throw error;

    await loadNotifications();
  } catch (error) {
    toast(friendlyError(error));
  }
}

async function markAllNotificationsRead() {
  const button = $("markAllNotificationsRead");

  setButtonLoading(button, true, "Updating...");

  try {
    const { error } = await supabaseClient
      .from("notifications")
      .update({ is_read: true })
      .eq("user_id", currentUser.id)
      .eq("is_read", false);

    if (error) throw error;

    notificationCount = 0;
    updateNotificationBadge();

    await loadNotifications();
    toast("Notifications marked as read.");
  } catch (error) {
    toast(friendlyError(error));
  } finally {
    if ($("markAllNotificationsRead")) {
      $("markAllNotificationsRead").disabled = false;
      $("markAllNotificationsRead").textContent = "Mark all as read";
    }
  }
}

async function refreshNotificationCount() {
  try {
    const { count, error } = await supabaseClient
      .from("notifications")
      .select("id", { count: "exact", head: true })
      .eq("user_id", currentUser.id)
      .eq("is_read", false);

    if (error) throw error;

    notificationCount = count || 0;
    updateNotificationBadge();
  } catch (error) {
    console.warn("Could not refresh notification count:", error);
  }
}

function subscribeToNotifications() {
  if (notificationChannel) {
    supabaseClient.removeChannel(notificationChannel);
    notificationChannel = null;
  }

  notificationChannel = supabaseClient
    .channel(`notifications-${currentUser.id}`)
    .on(
      "postgres_changes",
      {
        event: "INSERT",
        schema: "public",
        table: "notifications",
        filter: `user_id=eq.${currentUser.id}`
      },
      async () => {
        await refreshNotificationCount();

        if (currentPage === "notifications") {
          await loadNotifications();
        }

        toast("You have a new notification.");
      }
    )
    .subscribe();
}

// =====================================================
// VIDEO UPLOAD AND FEED
// =====================================================

async function publishVideo(event) {
  event.preventDefault();

  const button = $("publishVideo");
  const file = $("videoFile").files[0];

  if (!file) {
    toast("Choose a video first.");
    return;
  }

  if (!file.type.startsWith("video/")) {
    toast("The selected file is not a video.");
    return;
  }

  if (file.size > MAX_VIDEO_SIZE) {
    toast("Video is too large. Maximum size is 50 MB.");
    return;
  }

  setButtonLoading(button, true, "Uploading...");

  let path = null;

  try {
    path = getStoragePath(file);

    const { error: uploadError } = await supabaseClient.storage
      .from(VIDEO_BUCKET)
      .upload(path, file, {
        upsert: false,
        contentType: file.type
      });

    if (uploadError) throw uploadError;

    const { error: insertError } = await supabaseClient
      .from("videos")
      .insert({
        user_id: currentUser.id,
        caption: $("videoCaption").value.trim(),
        video_path: path
      });

    if (insertError) throw insertError;

    $("videoCaption").value = "";
    $("videoFile").value = "";
    $("videoFileInfo").textContent = "Maximum video size: 50 MB.";

    toast("Video published successfully.");

    await loadVideos();
  } catch (error) {
    if (path) {
      await supabaseClient.storage
        .from(VIDEO_BUCKET)
        .remove([path])
        .catch(() => {});
    }

    toast(friendlyError(error));
  } finally {
    if ($("publishVideo")) {
      $("publishVideo").disabled = false;
      $("publishVideo").textContent = "Publish video";
    }
  }
}

async function loadVideos() {
  const feed = $("videoFeed");
  
  if (!feed || !currentUser) return;
  
  feed.innerHTML = `
    <div class="card empty-state">Loading videos...</div>
  `;
  
  try {
    // 1. Load videos
    const { data: videos, error } = await supabaseClient
      .from("videos")
      .select("id,user_id,caption,video_path,created_at")
      .order("created_at", { ascending: false })
      .limit(30);
    
    if (error) throw error;
    
    if (!videos?.length) {
      feed.innerHTML = `
        <div class="card empty-state">
          <h3>No videos yet</h3>
          <p>Be the first to share a video.</p>
        </div>
      `;
      return;
    }
    
    const videoIds = videos.map(video => video.id);
    
    // 2. Load likes and comments
    const [
      { data: likes, error: likesError },
      { data: comments, error: commentsError }
    ] = await Promise.all([
      supabaseClient
      .from("video_likes")
      .select("id,video_id,user_id")
      .in("video_id", videoIds),
      
      supabaseClient
      .from("video_comments")
      .select("id,video_id,user_id,comment_text,created_at")
      .in("video_id", videoIds)
      .order("created_at", { ascending: true })
    ]);
    
    if (likesError) throw likesError;
    if (commentsError) throw commentsError;
    
    // 3. Load profiles for video owners and commenters
    const userIds = [
      ...new Set([
        ...videos.map(video => video.user_id),
        ...(comments || []).map(comment => comment.user_id)
      ])
    ];
    
    const { data: profiles, error: profilesError } =
    await supabaseClient
      .from("profiles")
      .select("id,full_name,bio,avatar_url")
      .in("id", userIds);
    
    if (profilesError) throw profilesError;
    
    const profileMap = new Map(
      (profiles || []).map(profile => [profile.id, profile])
    );
    
    const cards = await Promise.all(videos.map(async video => {
      const profile = profileMap.get(video.user_id) || {
        id: video.user_id,
        full_name: "ChatGram User",
        avatar_url: null
      };
      
      const videoLikes = (likes || []).filter(
        like => like.video_id === video.id
      );
      
      const videoComments = (comments || []).filter(
        comment => comment.video_id === video.id
      );
      
      const likedByMe = videoLikes.some(
        like => like.user_id === currentUser.id
      );
      
      const videoURL = await getStorageURL(
        VIDEO_BUCKET,
        video.video_path
      );
      
      const commentsHTML = videoComments.map(comment => {
        const commenter = profileMap.get(comment.user_id) || {
          full_name: "ChatGram User"
        };
        
        return `
          <div class="video-comment">
            <strong>
              ${escapeHTML(commenter.full_name || "ChatGram User")}
            </strong>

            <p>${escapeHTML(comment.comment_text)}</p>

            <small class="muted">
              ${escapeHTML(formatDate(comment.created_at))}
            </small>

            ${comment.user_id === currentUser.id ? `
              <button
                type="button"
                class="comment-delete-button"
                data-delete-comment="${escapeHTML(comment.id)}">
                Delete
              </button>
            ` : ""}
          </div>
        `;
      }).join("");
      
      return `
        <article
          class="video-card"
          data-video-id="${escapeHTML(video.id)}">

          ${videoURL ? `
            <video
              controls
              playsinline
              preload="metadata"
              src="${escapeHTML(videoURL)}">
            </video>
          ` : `
            <div class="empty-state">Video unavailable.</div>
          `}

          <div class="video-info">

            <div class="video-user">
              ${safeAvatarHTML(profile)}

              <div>
                <strong>
                  ${escapeHTML(profile.full_name || "ChatGram User")}
                </strong>

                <div class="muted">
                  ${escapeHTML(formatDate(video.created_at))}
                </div>
              </div>
            </div>

            <p class="video-caption">
              ${escapeHTML(video.caption || "")}
            </p>

            <!-- LIKE BUTTON -->
            <div class="video-social-actions">
              <button
                type="button"
                class="video-like-button ${likedByMe ? "liked" : ""}"
                data-toggle-like="${escapeHTML(video.id)}"
                aria-pressed="${likedByMe}">
                ${likedByMe ? "❤️ Liked" : "🤍 Like"}
                <span>${videoLikes.length}</span>
              </button>

              <span class="video-comment-count">
                💬 ${videoComments.length} comments
              </span>
            </div>

            <!-- COMMENTS -->
            <section class="video-comments-section">
              <h4>Comments (${videoComments.length})</h4>

              <div class="video-comments-list">
                ${commentsHTML || `
                  <p class="muted">
                    No comments yet. Be the first to comment!
                  </p>
                `}
              </div>

              <form
                class="video-comment-form"
                data-comment-form="${escapeHTML(video.id)}">

                <input
                  type="text"
                  name="comment"
                  maxlength="1000"
                  placeholder="Write a comment..."
                  aria-label="Write a comment"
                  required>

                <button type="submit">
                  Comment
                </button>
              </form>
            </section>

            <!-- EXISTING ACTIONS -->
            <div class="video-actions">
              ${video.user_id === currentUser.id ? `
                <button
                  type="button"
                  data-delete-video="${escapeHTML(video.id)}">
                  Delete
                </button>
              ` : ""}

              <button
                type="button"
                data-share-video="${escapeHTML(video.id)}">
                Share
              </button>
            </div>

          </div>
        </article>
      `;
    }));
    
    feed.innerHTML = cards.join("");
    
    // Like / unlike handlers
    feed.querySelectorAll("[data-toggle-like]").forEach(button => {
      button.onclick = () => toggleVideoLike(
        button.dataset.toggleLike
      );
    });
    
    // Comment form handlers
    feed.querySelectorAll("[data-comment-form]").forEach(form => {
     form.onsubmit = async event => {
      event.preventDefault();
        
        const input = form.querySelector('[name="comment"]');
        
        await submitVideoComment(
  form.dataset.commentForm,
  input.value,
  form
);
      };
    });
    
    // Delete own comment
    feed.querySelectorAll("[data-delete-comment]").forEach(button => {
      button.onclick = () => deleteVideoComment(
        button.dataset.deleteComment
      );
    });
    
    // ==========================================
// CHATGRAM VIDEO LIKES
// ==========================================

async function toggleVideoLike(videoId) {
  if (!currentUser || !supabaseClient) {
    toast("Please sign in first.");
    return;
  }
  
  const buttons = document.querySelectorAll("[data-toggle-like]");
  
  buttons.forEach(button => {
    if (button.dataset.toggleLike === videoId) {
      button.disabled = true;
    }
  });
  
  try {
    // Check whether the current user already liked this video.
    const { data: existingLike, error: findError } =
    await supabaseClient
      .from("video_likes")
      .select("id")
      .eq("video_id", videoId)
      .eq("user_id", currentUser.id)
      .maybeSingle();
    
    if (findError) throw findError;
    
    if (existingLike) {
      // Unlike
      const { error } = await supabaseClient
        .from("video_likes")
        .delete()
        .eq("id", existingLike.id)
        .eq("user_id", currentUser.id);
      
      if (error) throw error;
    } else {
      // Like
      const { error } = await supabaseClient
        .from("video_likes")
        .insert({
          video_id: videoId,
          user_id: currentUser.id
        });
      
      if (error) throw error;
    }
    
    await loadVideos();
    
  } catch (error) {
    console.error("Video like error:", error);
    toast(friendlyError(error));
  } finally {
    document.querySelectorAll("[data-toggle-like]").forEach(button => {
      if (button.dataset.toggleLike === videoId) {
        button.disabled = false;
      }
    });
  }
}


// ==========================================
// CHATGRAM VIDEO COMMENTS
// ==========================================

async function submitVideoComment(videoId, commentText, form) {
  if (!currentUser || !supabaseClient) {
    toast("Please sign in first.");
    return;
  }
  
  const text = String(commentText || "").trim();
  
  if (!text) {
    toast("Write a comment first.");
    return;
  }
  
  if (text.length > 1000) {
    toast("Your comment is too long.");
    return;
  }
  
  const input = form.querySelector('[name="comment"]');
  const submitButton = form.querySelector('button[type="submit"]');
  
  submitButton.disabled = true;
  
  try {
    const { error } = await supabaseClient
      .from("video_comments")
      .insert({
        video_id: videoId,
        user_id: currentUser.id,
        comment_text: text
      });
    
    if (error) throw error;
    
    toast("Comment added.");
    
    await loadVideos();
    
  } catch (error) {
    console.error("Video comment error:", error);
    toast(friendlyError(error));
  } finally {
    submitButton.disabled = false;
    
    if (input && document.body.contains(input)) {
      input.value = "";
    }
  }
}


// ==========================================
// DELETE YOUR OWN COMMENT
// ==========================================

async function deleteVideoComment(commentId) {
  if (!currentUser || !supabaseClient) return;
  
  if (!confirm("Delete your comment?")) return;
  
  try {
    const { error } = await supabaseClient
      .from("video_comments")
      .delete()
      .eq("id", commentId)
      .eq("user_id", currentUser.id);
    
    if (error) throw error;
    
    toast("Comment deleted.");
    
    await loadVideos();
    
  } catch (error) {
    console.error("Delete comment error:", error);
    toast(friendlyError(error));
  }
}
    
    // Preserve existing delete-video feature
    feed.querySelectorAll("[data-delete-video]").forEach(button => {
      button.onclick = () => deleteVideo(
        button.dataset.deleteVideo
      );
    });
    
    // Preserve existing share feature
    feed.querySelectorAll("[data-share-video]").forEach(button => {
      button.onclick = () => shareVideo(
        button.dataset.shareVideo
      );
    });
    
  } catch (error) {
    console.error("Video feed error:", error);
    
    feed.innerHTML = `
      <div class="card empty-state">
        <h3>Could not load videos</h3>
        <p>${escapeHTML(friendlyError(error))}</p>

        <button
          type="button"
          class="primary-button"
          id="retryVideos">
          Try again
        </button>
      </div>
    `;
    
    $("retryVideos").onclick = loadVideos;
  }
}

// =====================================================
// THEME
// =====================================================

function restoreTheme() {
  let dark = false;

  try {
    dark = localStorage.getItem("cgTheme") === "dark";
  } catch (error) {
    console.warn("Theme storage unavailable:", error);
  }

  document.body.classList.toggle("dark-mode", dark);

  if ($("themeState")) {
    $("themeState").textContent = dark ? "On" : "Off";
  }
}

function toggleTheme() {
  const dark = !document.body.classList.contains("dark-mode");

  document.body.classList.toggle("dark-mode", dark);

  try {
    localStorage.setItem("cgTheme", dark ? "dark" : "light");
  } catch (error) {
    console.warn("Theme preference could not be saved:", error);
  }

  if ($("themeState")) {
    $("themeState").textContent = dark ? "On" : "Off";
  }
}

// =====================================================
// LOGOUT AND CLEANUP
// =====================================================

function cleanupRealtime() {
  if (messageChannel) {
    supabaseClient.removeChannel(messageChannel);
    messageChannel = null;
  }

  if (notificationChannel) {
    supabaseClient.removeChannel(notificationChannel);
    notificationChannel = null;
  }

  if (conversationRefreshTimer) {
    clearInterval(conversationRefreshTimer);
    conversationRefreshTimer = null;
  }
}

async function logout() {
  if (!confirm("Are you sure you want to log out?")) return;

  try {
    cleanupRealtime();

    const { error } = await supabaseClient.auth.signOut();

    if (error) throw error;

    currentUser = null;
    currentProfile = null;
    activeConversationUser = null;
    activeConversationProfile = null;

    renderAuth("login");
  } catch (error) {
    toast(friendlyError(error));
  }
}

// =====================================================
// APPLICATION INITIALIZATION
// =====================================================

async function enterApp() {
  await loadProfile();

  await renderShell();

  subscribeToNotifications();

  await refreshNotificationCount();
}

async function initializeApp() {
  // Check whether Supabase SDK is available.
  if (!window.supabase) {
    $("app").innerHTML = `
      <section class="auth-screen">
        <div class="auth-card">
          <div class="auth-logo">C</div>
          <h1>ChatGram</h1>
          <p>ChatGram cannot connect to its required services.</p>
          <p class="muted">
            Check your internet connection, then reload the application.
          </p>
          <button class="primary-button" onclick="location.reload()">
            Retry
          </button>
        </div>
      </section>
    `;
    return;
  }
  
  try {
    // Initialize Supabase.
    supabaseClient = window.supabase.createClient(
      SUPABASE_URL,
      SUPABASE_PUBLISHABLE_KEY
    );
    
    // Restore the existing session.
    const { data, error } =
    await supabaseClient.auth.getSession();
    
    if (error) {
      throw error;
    }
    
    if (data.session?.user) {
      currentUser = data.session.user;
      await enterApp();
    } else {
      currentUser = null;
      renderAuth("signup");
    }
    
    // Listen for authentication changes.
    supabaseClient.auth.onAuthStateChange(
      async (event, session) => {
        if (event === "SIGNED_OUT") {
          cleanupRealtime();
          
          currentUser = null;
          currentProfile = null;
          activeConversationUser = null;
          activeConversationProfile = null;
          
          renderAuth("login");
        }
      }
    );
  } catch (error) {
    console.error("Initialization failed:", error);
    
    // Show a helpful offline screen instead of a confusing error.
    $("app").innerHTML = `
      <section class="auth-screen">
        <div class="auth-card">
          <div class="auth-logo">C</div>
          <h1>ChatGram</h1>
          <p id="chatgramOfflineMessage">
            ${navigator.onLine
              ? "ChatGram could not connect to its services."
              : "You are offline."}
          </p>
          <p class="muted">
            Connect to the internet to sign in and synchronize your account.
          </p>
          <button
            class="primary-button"
            onclick="location.reload()"
          >
            Try Again
          </button>
        </div>
      </section>
    `;
  }
}

document.addEventListener("DOMContentLoaded", initializeApp);

startApp();
// ============================================
// CHATGRAM OFFLINE MESSAGE QUEUE
// C's Fame
// ============================================

const CHATGRAM_DB_NAME = "chatgram_offline_db";
const CHATGRAM_DB_VERSION = 1;
const CHATGRAM_QUEUE_STORE = "pending_messages";

function openChatgramOfflineDB() {
  return new Promise((resolve, reject) => {
    if (!("indexedDB" in window)) {
      reject(new Error("Offline storage is not supported."));
      return;
    }

    const request = indexedDB.open(
      CHATGRAM_DB_NAME,
      CHATGRAM_DB_VERSION
    );

    request.onupgradeneeded = () => {
      const db = request.result;

      if (!db.objectStoreNames.contains(CHATGRAM_QUEUE_STORE)) {
        const store = db.createObjectStore(
          CHATGRAM_QUEUE_STORE,
          { keyPath: "client_message_id" }
        );

        store.createIndex("sender_id", "sender_id", {
          unique: false
        });

        store.createIndex("receiver_id", "receiver_id", {
          unique: false
        });

        store.createIndex("created_at", "created_at", {
          unique: false
        });
      }
    };

    request.onsuccess = () => resolve(request.result);

    request.onerror = () => reject(
      request.error || new Error("Could not open offline storage.")
    );
  });
}


// Save a message locally before attempting to send it.
async function savePendingChatgramMessage(message) {
  const db = await openChatgramOfflineDB();

  try {
    await new Promise((resolve, reject) => {
      const transaction = db.transaction(
        CHATGRAM_QUEUE_STORE,
        "readwrite"
      );

      transaction.objectStore(CHATGRAM_QUEUE_STORE).put(message);

      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error);
    });
  } finally {
    db.close();
  }
}


// Get queued messages belonging to the signed-in user.
async function getPendingChatgramMessages(userId) {
  const db = await openChatgramOfflineDB();

  try {
    return await new Promise((resolve, reject) => {
      const transaction = db.transaction(
        CHATGRAM_QUEUE_STORE,
        "readonly"
      );

      const request = transaction
        .objectStore(CHATGRAM_QUEUE_STORE)
        .index("sender_id")
        .getAll(userId);

      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  } finally {
    db.close();
  }
}


// Remove a message only after the server accepts it.
async function removePendingChatgramMessage(clientMessageId) {
  const db = await openChatgramOfflineDB();

  try {
    await new Promise((resolve, reject) => {
      const transaction = db.transaction(
        CHATGRAM_QUEUE_STORE,
        "readwrite"
      );

      transaction.objectStore(CHATGRAM_QUEUE_STORE)
        .delete(clientMessageId);

      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error);
    });
  } finally {
    db.close();
  }
}


// Send pending messages when internet returns.
let chatgramSyncRunning = false;

async function syncPendingChatgramMessages() {
  if (
    chatgramSyncRunning ||
    !navigator.onLine ||
    !currentUser ||
    !supabaseClient
  ) {
    return;
  }

  chatgramSyncRunning = true;

  try {
    const pendingMessages = await getPendingChatgramMessages(
      currentUser.id
    );

    for (const message of pendingMessages) {
      if (!navigator.onLine) break;

      // Never send a queued message belonging to another account.
      if (message.sender_id !== currentUser.id) continue;

      const { error } = await supabaseClient
        .from("messages")
        .upsert(
          {
            sender_id: message.sender_id,
            receiver_id: message.receiver_id,
            message_text: message.message_text,
            client_message_id: message.client_message_id
          },
          {
            onConflict: "sender_id,client_message_id",
            ignoreDuplicates: true
          }
        );

      if (error) {
        console.warn(
          "ChatGram message is still pending:",
          error.message
        );

        // Keep it in IndexedDB and retry later.
        break;
      }

      await removePendingChatgramMessage(
        message.client_message_id
      );
    }

    if (typeof loadConversationMessages === "function") {
      if (activeConversationUser) {
        await loadConversationMessages();
      }
    }
  } catch (error) {
    console.warn("ChatGram offline sync:", error);
  } finally {
    chatgramSyncRunning = false;
  }
}


// Retry automatically when the connection returns.
window.addEventListener("online", () => {
  syncPendingChatgramMessages();
});

// Retry when the app becomes active.
document.addEventListener("visibilitychange", () => {
  if (!document.hidden) {
    syncPendingChatgramMessages();
  }
});