 "use strict";

/* ==========================================
   CHATGRAM — C'S FAME
   Supabase application
   ========================================== */

/* 1. SUPABASE CONFIGURATION */

const SUPABASE_URL =
  "https://wgmlhqfwvcyrkslarfra.supabase.co";

const SUPABASE_KEY =
  "sb_publishable_-6GYSlWtBvCffUSZQ7UlAw_FGY5z4a8";

if (!window.supabase) {
  console.error("Supabase library ntiraboneka.");
  alert("Supabase ntiyafungutse. Ongera ufungure internet.");
  throw new Error("Supabase library missing");
}

const db = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_KEY
);

function getVideoPublicURL(videoPath) {
  if (!videoPath) return "";
  
  const path = String(videoPath).trim();
  
  // Niba ari URL ya Supabase Signed cyangwa Public
  if (path.includes("/storage/v1/object/")) {
    const marker = "/storage/v1/object/";
    const index = path.indexOf(marker);
    const objectPath = path.substring(index + marker.length);
    
    // Kuramo token n'ibindi biri nyuma ya ?
    const cleanObjectPath = objectPath.split("?")[0];
    
    // Hindura signed URL ibe public URL
    if (cleanObjectPath.startsWith("sign/videos/")) {
      const filePath = cleanObjectPath.substring("sign/videos/".length);
      
      return `${SUPABASE_URL}/storage/v1/object/public/videos/${filePath}`;
    }
    
    if (cleanObjectPath.startsWith("public/videos/")) {
      return `${SUPABASE_URL}/storage/v1/object/public/videos/${cleanObjectPath.substring("public/videos/".length)}`;
    }
  }
  
  // Niba database ibitse path gusa
  const cleanPath = path
    .replace(/^\/+/, "")
    .replace(/^videos\//, "");
  
  return db.storage
    .from("videos")
    .getPublicUrl(cleanPath)
    .data.publicUrl;
}
/* 2. APPLICATION STATE */

let currentUser = null;
let currentProfile = null;
let activeChatUser = null;
let activePage = "home";

let loadedVideos = [];
let loadedMessages = [];

let messagePolling = null;
let toastTimer = null;


/* 3. HELPERS */

const $ = (selector) => document.querySelector(selector);

const $$ = (selector) =>
  Array.from(document.querySelectorAll(selector));

function element(id) {
  return document.getElementById(id);
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => {
    const replacements = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    };

    return replacements[char];
  });
}

function formatDate(value) {
  if (!value) return "";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return "";

  return date.toLocaleString();
}

function getInitials(name) {
  const words = String(name || "User")
    .trim()
    .split(/\s+/)
    .filter(Boolean);

  return words
    .slice(0, 2)
    .map(word => word.charAt(0).toUpperCase())
    .join("") || "U";
}

function avatarURL(profile) {
  if (profile?.avatar_url) {
    return profile.avatar_url;
  }

  return (
    "data:image/svg+xml;charset=UTF-8," +
    encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" width="120" height="120">
        <rect width="120" height="120" rx="60" fill="#30313a"/>
        <text x="60" y="70" font-size="42" text-anchor="middle"
          fill="white" font-family="Arial">
          ${getInitials(profile?.full_name)}
        </text>
      </svg>
    `)
  );
}

function showToast(message, duration = 3500) {
  let toast = element("chatgram-toast");

  if (!toast) {
    toast = document.createElement("div");
    toast.id = "chatgram-toast";
    toast.className = "toast";
    document.body.appendChild(toast);
  }

  toast.textContent = message;
  toast.hidden = false;

  clearTimeout(toastTimer);

  toastTimer = setTimeout(() => {
    toast.hidden = true;
  }, duration);
}

function setStatus(id, message) {
  const target = element(id);

  if (target) {
    target.textContent = message;
  }
}

function setButtonLoading(button, loading, loadingText = "Tegereza...") {
  if (!button) return;

  if (loading) {
    button.dataset.originalText = button.textContent;
    button.textContent = loadingText;
    button.disabled = true;
  } else {
    button.textContent =
      button.dataset.originalText || button.textContent;

    button.disabled = false;
  }
}

function setImage(img, profile) {
  if (!img) return;

  img.src = avatarURL(profile);

  img.onerror = () => {
    img.onerror = null;
    img.src = avatarURL(null);
  };
}

function showError(action, error) {
  console.error(action, error);

  const message =
    error?.message ||
    error?.details ||
    "Ikibazo kitazwi cyabaye.";

  showToast(`${action}: ${message}`, 6000);
}


/* 4. PAGE VISIBILITY */

function showAuthScreen() {
  const authScreen = element("authScreen");
  const app = element("app");

  if (authScreen) authScreen.hidden = false;
  if (app) app.hidden = true;

  stopMessagePolling();
}

function showMainApp() {
  const authScreen = element("authScreen");
  const app = element("app");

  if (authScreen) authScreen.hidden = true;
  if (app) app.hidden = false;
}

function showPage(pageName) {
  const allowedPages = [
    "home",
    "upload",
    "messages",
    "profile"
  ];

  if (!allowedPages.includes(pageName)) {
    pageName = "home";
  }

  activePage = pageName;

  $$(".page").forEach(page => {
    page.hidden = page.id !== pageName;
  });

  $$("[data-page]").forEach(button => {
    const active = button.dataset.page === pageName;

    button.classList.toggle("active", active);

    if (active) {
      button.setAttribute("aria-current", "page");
    } else {
      button.removeAttribute("aria-current");
    }
  });

  if (pageName === "home") {
    loadVideos();
  }

  if (pageName === "profile") {
    loadProfile();
    loadProfileVideos();
  }

  if (pageName === "messages") {
    loadMessageUsers();
  }

  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
}


/* 5. AUTHENTICATION */

async function signUp(event) {
  event.preventDefault();

  const form = element("signupForm");
  const button = form?.querySelector('button[type="submit"]');

  const name = element("signupName")?.value.trim();
  const email = element("signupEmail")?.value.trim();
  const password = element("signupPassword")?.value;

  if (!name || !email || !password) {
    showToast("Uzuza ibisabwa byose.");
    return;
  }

  setButtonLoading(button, true, "Turimo gukora konti...");

  try {
    const { data, error } = await db.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: name
        }
      }
    });

    if (error) throw error;

    if (data.user && data.session) {
      currentUser = data.user;

      await ensureProfile(name);
      await enterApp();

      showToast("Konti yawe yakozwe neza!");
    } else {
      showToast(
        "Konti yakozwe. Reba email yawe niba usabwa kuyemeza."
      );

      const loginForm = element("loginForm");

      if (loginForm) loginForm.hidden = false;
      if (form) form.hidden = true;
    }
  } catch (error) {
    showError("Kwiyandikisha byanze", error);
  } finally {
    setButtonLoading(button, false);
  }
}

async function signIn(event) {
  event.preventDefault();

  const form = element("loginForm");
  const button = form?.querySelector('button[type="submit"]');

  const email = element("loginEmail")?.value.trim();
  const password = element("loginPassword")?.value;

  if (!email || !password) {
    showToast("Andika email na password.");
    return;
  }

  setButtonLoading(button, true, "Turimo kukwinjiza...");

  try {
    const { data, error } = await db.auth.signInWithPassword({
      email,
      password
    });

    if (error) throw error;

    currentUser = data.user;

    await enterApp();

    showToast("Winjiye muri ChatGram!");
  } catch (error) {
    showError("Kwinjira byanze", error);
  } finally {
    setButtonLoading(button, false);
  }
}

async function signOut() {
  const confirmed = window.confirm(
    "Urashaka gusohoka muri konti yawe?"
  );

  if (!confirmed) return;

  try {
    stopMessagePolling();

    const { error } = await db.auth.signOut();

    if (error) throw error;

    currentUser = null;
    currentProfile = null;
    activeChatUser = null;

    showAuthScreen();

    showToast("Wasohotse muri konti yawe.");
  } catch (error) {
    showError("Gusohoka byanze", error);
  }
}


/* 6. USER PROFILE */

async function ensureProfile(fullName = "") {
  if (!currentUser) return null;

  const { data: existing, error: selectError } = await db
    .from("profiles")
    .select("*")
    .eq("id", currentUser.id)
    .maybeSingle();

  if (selectError) throw selectError;

  if (existing) {
    currentProfile = existing;
    return existing;
  }

  const profile = {
    id: currentUser.id,
    full_name:
      fullName ||
      currentUser.user_metadata?.full_name ||
      currentUser.email?.split("@")[0] ||
      "User",
    bio: "",
    updated_at: new Date().toISOString()
  };

  const { data, error } = await db
    .from("profiles")
    .upsert(profile, { onConflict: "id" })
    .select()
    .single();

  if (error) throw error;

  currentProfile = data;

  return data;
}

async function loadProfile() {
  if (!currentUser) return;

  try {
    const { data, error } = await db
      .from("profiles")
      .select("*")
      .eq("id", currentUser.id)
      .maybeSingle();

    if (error) throw error;

    currentProfile = data || await ensureProfile();

    const name = currentProfile?.full_name || "User";
    const bio = currentProfile?.bio || "";

    if (element("profileName")) {
      element("profileName").textContent = name;
    }

    if (element("profileEmail")) {
      element("profileEmail").textContent =
        currentUser.email || "";
    }

    if (element("profileBio")) {
      element("profileBio").textContent = bio;
    }

    if (element("editFullName")) {
      element("editFullName").value = name;
    }

    if (element("editBio")) {
      element("editBio").value = bio;
    }

    setImage(element("profileAvatar"), currentProfile);
    setImage(element("sidebarAvatar"), currentProfile);
  } catch (error) {
    showError("Gufungura profile byanze", error);
  }
}

/* =====================================
   CHATGRAM — LOAD MY PROFILE VIDEOS
===================================== */

async function loadProfileVideos() {
  const container = element("profileVideos");
  
  if (!container) return;
  
  if (!currentUser) {
    container.innerHTML =
      '<p class="empty-message">Banza winjire muri konti yawe.</p>';
    return;
  }
  
  container.innerHTML =
    '<p class="empty-message">Turimo kuzana amavideo yawe...</p>';
  
  try {
    const { data: videos, error } = await db
      .from("videos")
      .select("id, user_id, caption, video_path, created_at")
      .eq("user_id", currentUser.id)
      .order("created_at", { ascending: false });
    
    if (error) throw error;
    
    if (!videos || videos.length === 0) {
      container.innerHTML =
        '<p class="empty-message">Nta video urashyira kuri profile yawe.</p>';
      return;
    }
    
    function getProfileVideoURL(path) {
      if (!path) return "";
      
      const value = String(path).trim();
      
      // URL isanzwe iboneka muri database
      if (/^https?:\/\//i.test(value)) {
        return value;
      }
      
      // Niba database ibitse path aho kubika URL
      const cleanPath = value
        .replace(/^\/+/, "")
        .replace(/^videos\//, "");
      
      const { data } = db.storage
        .from("videos")
        .getPublicUrl(cleanPath);
      
      return data?.publicUrl || "";
    }
    
    container.innerHTML = videos.map(video => {
      const videoURL = getProfileVideoURL(video.video_path);
      return `
        <article
          class="profile-video-card"
          data-video-id="${escapeHTML(video.id)}"
        >
          ${
            videoURL
              ? `
                <video
                  class="profile-video-player"
                  src="${escapeHTML(videoURL)}"
                  controls
                  playsinline
                  preload="metadata"
                  style="
                    display:block;
                    width:100%;
                    max-height:500px;
                    background:#000;
                    border-radius:10px;
                  "
                ></video>
              `
              : `
                <p class="empty-message">
                  URL ya video ntibonetse.
                </p>
              `
          }

          ${
            video.caption
              ? `
                <p class="profile-video-caption">
                  ${escapeHTML(video.caption)}
                </p>
              `
              : ""
          }

          <small>
            ${escapeHTML(formatDate(video.created_at))}
          </small>

          <button
            type="button"
            class="delete-video-btn"
            data-action="delete-video"
            data-id="${escapeHTML(video.id)}"
          >
            delete
          </button>
        </article>
      `;
    }).join("");
    
  } catch (error) {
    console.error("loadProfileVideos error:", error);
    
    container.innerHTML =
      '<p class="empty-message">Ntitwashoboye kuzana amavideo yawe. Gerageza kongera.</p>';
    
    showError("Gufungura amavideo ya profile byanze", error);
  }
}


/* =====================================
   CHATGRAM — PROFILE VIDEO DELETE
===================================== */

const profileVideosContainer = element("profileVideos");

if (
  profileVideosContainer &&
  profileVideosContainer.dataset.deleteHandlerReady !== "yes"
) {
  profileVideosContainer.dataset.deleteHandlerReady = "yes";
  
  profileVideosContainer.addEventListener("click", async event => {
    const button = event.target.closest(
      'button[data-action="delete-video"]'
    );
    
    if (!button || !profileVideosContainer.contains(button)) {
      return;
    }
    
    event.preventDefault();
    event.stopPropagation();
    
    const videoId = button.dataset.id;
    
    if (!videoId) {
      showToast("Video ntiyabonetse.");
      return;
    }
    
    if (typeof deleteMyVideo !== "function") {
      showToast("Function yo gusiba video ntiraboneka.");
      return;
    }
    
    await deleteMyVideo(videoId);
  });
}

async function saveProfile() {
  if (!currentUser) return;

  const name = element("editFullName")?.value.trim();
  const bio = element("editBio")?.value.trim();

  if (!name) {
    showToast("Andika izina ryawe.");
    return;
  }

  const button = $('[data-action="save-profile"]');

  setButtonLoading(button, true, "Turimo kubika...");

  try {
    const updatedProfile = {
      id: currentUser.id,
      full_name: name,
      bio: bio || "",
      updated_at: new Date().toISOString()
    };

    const { data, error } = await db
      .from("profiles")
      .upsert(updatedProfile, { onConflict: "id" })
      .select()
      .single();

    if (error) throw error;

    currentProfile = data;

    await loadProfile();

    showToast("Profile yawe yabitswe neza!");
  } catch (error) {
    showError("Kubika profile byanze", error);
  } finally {
    setButtonLoading(button, false);
  }
}

async function uploadAvatar(event) {
  const file = event.target.files?.[0];

  if (!file || !currentUser) return;

  if (!file.type.startsWith("image/")) {
    showToast("Hitamo ifoto.");
    event.target.value = "";
    return;
  }

  if (file.size > 5 * 1024 * 1024) {
    showToast("Ifoto igomba kuba itarengeje 5 MB.");
    event.target.value = "";
    return;
  }

  try {
    showToast("Turimo kohereza ifoto...");

    const extension =
      file.name.split(".").pop()?.toLowerCase() || "jpg";

    const path =
      `${currentUser.id}/${Date.now()}.${extension}`;

    const { error: uploadError } = await db.storage
      .from("avatars")
      .upload(path, file, {
        upsert: false,
        contentType: file.type
      });

    if (uploadError) throw uploadError;

    const { data: publicData } = db.storage
      .from("avatars")
      .getPublicUrl(path);

    const avatarUrl = publicData.publicUrl;

    const { data, error } = await db
      .from("profiles")
      .upsert({
        id: currentUser.id,
        full_name:
          currentProfile?.full_name ||
          currentUser.user_metadata?.full_name ||
          "User",
        bio: currentProfile?.bio || "",
        avatar_url: avatarUrl,
        updated_at: new Date().toISOString()
      }, { onConflict: "id" })
      .select()
      .single();

    if (error) throw error;

    currentProfile = data;

    await loadProfile();

    showToast("Ifoto ya profile yahinduwe!");
  } catch (error) {
    showError("Guhindura ifoto byanze", error);
  } finally {
    event.target.value = "";
  }
}


/* 7. VIDEO UPLOAD */

function setupVideoPreview() {
  const input = element("videoFile");
  const wrapper = element("videoPreview");
  const video = element("selectedVideoPreview");

  if (!input || !wrapper || !video) return;

  input.addEventListener("change", () => {
    const file = input.files?.[0];

    if (!file) {
      video.removeAttribute("src");
      wrapper.hidden = true;
      return;
    }

    if (!file.type.startsWith("video/")) {
      showToast("Hitamo video yemewe.");
      input.value = "";
      wrapper.hidden = true;
      return;
    }

    const previousURL = video.dataset.objectUrl;

    if (previousURL) {
      URL.revokeObjectURL(previousURL);
    }

    const url = URL.createObjectURL(file);

    video.src = url;
    video.dataset.objectUrl = url;
    wrapper.hidden = false;
  });
}
async function uploadVideo(event) {
  event.preventDefault();
  
  if (!currentUser) {
    showToast("Banza winjire muri konti yawe.");
    return;
  }
  
  if (!window.tus) {
    showToast("TUS ntiyafungutse. Reba internet wongere ufungure app.");
    return;
  }
  
  const input = element("videoFile");
  const captionInput = element("videoCaption");
  const form = element("videoUploadForm");
  const button = form?.querySelector('button[type="submit"]');
  
  const file = input?.files?.[0];
  const caption = captionInput?.value.trim() || "";
  
  if (!file) {
    showToast("Banza uhitemo video.");
    return;
  }
  
  if (!file.type.startsWith("video/")) {
    showToast("File wahisemo si video.");
    return;
  }
  
  if (file.size > 100 * 1024 * 1024) {
    showToast("Video irenze 100 MB. Hitamo ntoya.");
    return;
  }
  
  setButtonLoading(button, true, "Turimo kohereza video...");
  setStatus("videoUploadStatus", "Tegereza: 0%");
  
  try {
    const extension =
      file.name.split(".").pop()?.toLowerCase() || "mp4";
    
    const path = `${currentUser.id}/${Date.now()}.${extension}`;
    
    const { data: sessionData, error: sessionError } =
    await db.auth.getSession();
    
    if (sessionError) throw sessionError;
    
    const accessToken = sessionData?.session?.access_token;
    
    if (!accessToken) {
      throw new Error("Session yarangiye. Ongera winjire muri konti yawe.");
    }
    
    const projectURL = SUPABASE_URL.replace(/\/+$/, "");
    const uploadEndpoint =
      `${projectURL}/storage/v1/upload/resumable`;
    
    await new Promise((resolve, reject) => {
      const upload = new window.tus.Upload(file, {
        endpoint: uploadEndpoint,
       retryDelays: [0, 1000, 2000, 3000, 5000],
  chunkSize: 2 * 1024 * 1024,
        
        headers: {
          authorization: `Bearer ${accessToken}`,
          apikey: SUPABASE_KEY,
          "x-upsert": "false"
        },
        
        metadata: {
          bucketName: "videos",
          objectName: path,
          contentType: file.type || "video/mp4",
          cacheControl: "3600"
        },
        
        onError(error) {
          reject(error);
        },
        
        onProgress(bytesUploaded, bytesTotal) {
          const percent = Math.round(
            (bytesUploaded / bytesTotal) * 100
          );
          
          setStatus(
            "videoUploadStatus",
            `Video irimo koherezwa: ${percent}%`
          );
        },
        
        onSuccess() {
          setStatus(
            "videoUploadStatus",
            "100% — Turimo kubika amakuru ya video..."
          );
          
          resolve();
        }
      });
      
      upload.start();
    });
    
    const { data: publicData } = db.storage
      .from("videos")
      .getPublicUrl(path);
    
    if (!publicData?.publicUrl) {
      throw new Error("Ntitwashoboye kubona URL ya video.");
    }
    
    const { error: insertError } = await db
      .from("videos")
      .insert({
        user_id: currentUser.id,
        caption,
        video_path: publicData.publicUrl
      });
    
    if (insertError) {
      throw new Error(
        "Video yoherejwe, ariko kubika amakuru muri database byanze: " +
        insertError.message
      );
    }
    
    form?.reset();
    
    const preview = element("videoPreview");
    const previewVideo = element("selectedVideoPreview");
    
    if (preview) preview.hidden = true;
    
    if (previewVideo) {
      if (previewVideo.dataset.objectUrl) {
        URL.revokeObjectURL(previewVideo.dataset.objectUrl);
        delete previewVideo.dataset.objectUrl;
      }
      
      previewVideo.removeAttribute("src");
      previewVideo.load();
    }
    
    setStatus("videoUploadStatus", "");
    showToast("Video yawe yashyizwe kuri ChatGram!");
    showPage("home");
    
  } catch (error) {
    console.error("ChatGram TUS upload error:", error);
    
    showError("Kohereza video byanze", error);
    
setStatus("videoUploadStatus", "");
showToast("Video yawe yashyizwe kuri ChatGram!");

await loadVideos();

showPage("home");
    
  } finally {
    setButtonLoading(button, false);
  }
}
function getVideoPublicURL(videoPath) {
  if (!videoPath) return "";
  
  const path = String(videoPath).trim();
  
  // Video ishobora kuba isanzwe ifite URL yuzuye
  if (path.startsWith("https://") || path.startsWith("http://")) {
    return path;
  }
  
  // Fata path iri muri bucket ya videos
  const { data } = db.storage
    .from("videos")
    .getPublicUrl(path.replace(/^\/+/, ""));
  
  return data?.publicUrl || "";
}



async function fetchVideosFromMyFolder() {
  const folder = "c4be44d0-c4eb-41c0-887c-04f418db6029";
  
  const { data, error } = await db.storage
    .from("videos")
    .list(folder, {
      limit: 100,
      sortBy: {
        column: "name",
        order: "desc"
      }
    });
  
  if (error) {
    console.error("VIDEO FETCH ERROR:", error.message);
    return [];
  }
  
  return (data || [])
    .filter(file => /\.(mp4|webm|JPG|GIF|PNG|JIFF|mov|m4v|ogv)$/i.test(file.name))
    .map(file => {
      const path = `${folder}/${file.name}`;
      
      const { data: publicData } = db.storage
        .from("videos")
        .getPublicUrl(path);
      
      return {
        name: file.name,
        video_path: path,
        video_url: publicData.publicUrl
      };
    });
}

/* COMMENT LIKE — INSTAGRAM STYLE */

async function toggleCommentLike(commentId) {
  if (!currentUser) {
    showToast("Banza winjire muri konti yawe.");
    return;
  }
  
  if (!commentId) {
    showToast("Comment ntiyabonetse.");
    return;
  }
  
  const buttons = document.querySelectorAll(
    '.comment-like-btn[data-id="' + CSS.escape(String(commentId)) + '"]'
  );
  
  const button = buttons[0];
  
  if (!button || button.dataset.loading === "yes") return;
  
  button.dataset.loading = "yes";
  button.disabled = true;
  
  try {
    const { data: existing, error: findError } = await db
      .from("video_comment_likes")
      .select("id")
      .eq("comment_id", commentId)
      .eq("user_id", currentUser.id)
      .maybeSingle();
    
    if (findError) throw findError;
    
    if (existing) {
      const { error } = await db
        .from("video_comment_likes")
        .delete()
        .eq("id", existing.id)
        .eq("user_id", currentUser.id);
      
      if (error) throw error;
      
      button.setAttribute("aria-pressed", "false");
      button.classList.remove("liked");
      
      const match = button.textContent.match(/\d+/);
      const count = match ? Number(match[0]) : 1;
      
      button.innerHTML = `🤍 ${Math.max(0, count - 1)}`;
    } else {
      const { error } = await db
        .from("video_comment_likes")
        .insert({
          comment_id: commentId,
          user_id: currentUser.id
        });
      
      if (error) throw error;
      
      button.setAttribute("aria-pressed", "true");
      button.classList.add("liked");
      
      const match = button.textContent.match(/\d+/);
      const count = match ? Number(match[0]) : 0;
      
      button.innerHTML = `❤️ ${count + 1}`;
    }
  } catch (error) {
    console.error("Comment like error:", error);
    showError("Gutanga like kuri kuri kunanirana", error);
  } finally {
    button.dataset.loading = "no";
    button.disabled = false;
  }
}



/* 8. LOAD VIDEOS */

async function loadVideos() {
  const feed = element("videosFeed");
  if (!feed) return;

  feed.innerHTML =
    '<p class="empty-message">Turimo gushaka amavideo...</p>';

  try {
    const { data, error } = await db
      .from("videos")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50);

    if (error) throw error;

    loadedVideos = data || [];

    if (!loadedVideos.length) {
      feed.innerHTML =
        '<p class="empty-message">Nta video ziri muri database.</p>';
      return;
    }

    function resolveVideoURL(videoPath) {
      if (!videoPath) return "";

      const path = String(videoPath).trim();

      if (
        path.includes("/storage/v1/object/sign/videos/")
      ) {
        try {
          const url = new URL(path);
          const marker =
            "/storage/v1/object/sign/videos/";
          const filePath = url.pathname.split(marker)[1];

          if (filePath) {
            return (
              `${SUPABASE_URL}/storage/v1/object/public/videos/` +
              filePath
                .split("/")
                .map(encodeURIComponent)
                .join("/")
            );
          }
        } catch (error) {
          console.error("Video URL error:", error);
          return "";
        }
      }

      if (
        path.includes("/storage/v1/object/public/videos/")
      ) {
        return path.split("?")[0];
      }

      const cleanPath = path
        .replace(/^\/+/, "")
        .replace(/^videos\//, "");

      const { data } = db.storage
        .from("videos")
        .getPublicUrl(cleanPath);

      return data?.publicUrl || "";
    }

    // 1. Get video owners.
    const userIds = [
      ...new Set(
        loadedVideos
          .map(video => video.user_id)
          .filter(Boolean)
      )
    ];

    let profiles = [];

    if (userIds.length) {
      const result = await db
        .from("profiles")
        .select("id, full_name, avatar_url")
        .in("id", userIds);

      if (result.error) throw result.error;
      profiles = result.data || [];
    }

    const profileMap = new Map(
      profiles.map(profile => [profile.id, profile])
    );

    // 2. Get video likes.
    const videoIds = loadedVideos.map(video => video.id);

    const likesResult = await db
      .from("video_likes")
      .select("id, video_id, user_id")
      .in("video_id", videoIds);

    if (likesResult.error) throw likesResult.error;

    const likes = likesResult.data || [];

    // 3. Get comments.
    const commentsResult = await db
      .from("video_comments")
      .select(
        "id, video_id, user_id, comment_text, created_at"
      )
      .in("video_id", videoIds)
      .order("created_at", { ascending: true });

    if (commentsResult.error) throw commentsResult.error;

    const comments = commentsResult.data || [];

    // 4. Get comment likes.
    const commentIds = comments.map(comment => comment.id);
    let commentLikes = [];

    if (commentIds.length) {
      const result = await db
        .from("video_comment_likes")
        .select("id, comment_id, user_id")
        .in("comment_id", commentIds);

      if (result.error) throw result.error;
      commentLikes = result.data || [];
    }

    // 5. Get comment authors.
    const commentUserIds = [
      ...new Set(
        comments
          .map(comment => comment.user_id)
          .filter(Boolean)
      )
    ];

    let commentProfiles = [];

    if (commentUserIds.length) {
      const result = await db
        .from("profiles")
        .select("id, full_name")
        .in("id", commentUserIds);

      if (result.error) throw result.error;
      commentProfiles = result.data || [];
    }

    const commentNameMap = new Map(
      commentProfiles.map(profile => [
        profile.id,
        profile.full_name || "User"
      ])
    );

    // 6. Render videos and comments.
    feed.innerHTML = loadedVideos.map(video => {
      const owner = profileMap.get(video.user_id) || {};
      const videoURL = resolveVideoURL(video.video_path);

      const videoLikes = likes.filter(
        like => like.video_id === video.id
      );

      const videoComments = comments.filter(
        comment => comment.video_id === video.id
      );

      const liked = videoLikes.some(
        like => like.user_id === currentUser?.id
      );

      const commentHTML = videoComments
        .map((comment, index) => {
          const thisCommentLikes = commentLikes.filter(
            like =>
              String(like.comment_id) === String(comment.id)
          );

          const commentLiked = thisCommentLikes.some(
            like => like.user_id === currentUser?.id
          );

          const isMine =
            currentUser &&
            String(comment.user_id) === String(currentUser.id);

          const commentAuthor =
            commentNameMap.get(comment.user_id) || "User";

          return `
            <div
              class="comment-item"
              data-comment-id="${escapeHTML(comment.id)}"
              ${index >= 2 ? "hidden" : ""}
            >
              <div class="comment-content">
                <button
                  type="button"
                  class="comment-author-btn"
                  data-action="message-comment-author"
                  data-user-id="${escapeHTML(comment.user_id || "")}"
                  style="border:0;background:none;padding:0;font-weight:bold;cursor:pointer;"
                >${escapeHTML(commentAuthor)}</button>

                <span>
                  ${escapeHTML(comment.comment_text || "")}
                </span>
              </div>

              <div class="comment-actions">
                <button
                  type="button"
                  class="comment-like-btn"
                  data-action="comment-like"
                  data-id="${escapeHTML(comment.id)}"
                  aria-pressed="${commentLiked}"
                >
                  ${commentLiked ? "❤️" : "🤍"}
                  ${thisCommentLikes.length}
                </button>

                ${
                  isMine
                    ? `
                      <button
                        type="button"
                        class="comment-delete-btn"
                        data-action="delete-comment"
                        data-id="${escapeHTML(comment.id)}"
                      > delete</button>
                    `
                    : ""
                }
              </div>
            </div>
          `;
        })
        .join("");

      return `
        <article
          class="video-card"
          data-video-id="${escapeHTML(video.id)}"
        >
          <div class="video-owner">
            <img
              class="avatar avatar-small"
              src="${escapeHTML(avatarURL(owner))}"
              alt=""
            >

            <div>
              <strong>
                ${escapeHTML(owner.full_name || "User")}
              </strong>
              <small>
                ${escapeHTML(formatDate(video.created_at))}
              </small>
            </div>
          </div>

          ${
            video.caption
              ? `<p class="video-caption">${escapeHTML(video.caption)}</p>`
              : ""
          }

          ${
            videoURL
              ? `
                <video
                  class="feed-video"
                  src="${escapeHTML(videoURL)}"
                  controls
                  playsinline
                  webkit-playsinline
                  preload="metadata"
                  style="display:block;width:100%;max-height:75vh;background:#000;"
                ></video>
              `
              : `
                <p class="empty-message">
                  URL ya video ntibonetse.
                </p>
              `
          }

          <div class="video-actions">
            <button
              type="button"
              class="like-btn ${liked ? "liked" : ""}"
              data-action="like"
              data-id="${escapeHTML(video.id)}"
              aria-pressed="${liked}"
            >
              ${liked ? "❤️" : "🤍"} ${videoLikes.length} Likes
            </button>

            <button
              type="button"
              class="comment-toggle"
              data-action="toggle-comments"
              data-id="${escapeHTML(video.id)}"
            >
              💬 ${videoComments.length} Comments
            </button>

            <button
              type="button"
              data-action="share"
              data-id="${escapeHTML(video.id)}"
            >
              ↗ Share
            </button>
          </div>

          <div
            class="video-comments"
            id="comments-${escapeHTML(video.id)}"
          >
            <div class="comments-list">
              ${
                commentHTML ||
                '<p class="empty-message">Nta comments zirahari.</p>'
              }
            </div>

            ${
              videoComments.length > 2
                ? `
                  <button
                    type="button"
                    class="show-all-comments"
                    data-action="show-all-comments"
                  >
                    Reba comments zose (${videoComments.length})
                  </button>
                `
                : ""
            }

            <form
              class="comment-form"
              data-video-id="${escapeHTML(video.id)}"
            >
              <input
                type="text"
                name="comment_text"
                maxlength="1000"
                placeholder="Andika comment..."
                required
              >

              <button type="submit">Ohereza</button>
            </form>
          </div>
        </article>
      `;
    }).join("");

    // 7. Register ONE click handler.
    if (feed.dataset.commentActionsReady !== "yes") {
      feed.dataset.commentActionsReady = "yes";

      feed.addEventListener("click", async event => {
        const button = event.target.closest(
          "button[data-action]"
        );

        if (!button || !feed.contains(button)) return;

        const action = button.dataset.action;
        
        if (action === "delete-video") {
  event.preventDefault();
  event.stopPropagation();
  
  await deleteMyVideo(button.dataset.id);
  return;
}

        if (action === "message-comment-author") {
          event.preventDefault();
          event.stopPropagation();

          const userId = button.dataset.userId;

          if (!userId) {
            showToast("ID y'uyu muntu ntiyabonetse.");
            return;
          }

          if (!currentUser) {
            showToast("Banza winjire muri konti yawe.");
            return;
          }

          if (userId === currentUser.id) {
            showToast("Iyi ni konti yawe.");
            return;
          }

          await openChat(userId);
          return;
        }

        if (action === "show-all-comments") {
          event.preventDefault();

          const list = button.parentElement.querySelector(
            ".comments-list"
          );

          if (list) {
            list
              .querySelectorAll(".comment-item[hidden]")
              .forEach(item => {
                item.hidden = false;
              });
          }

          button.remove();
          return;
        }

        if (action === "comment-like") {
          event.preventDefault();
          event.stopPropagation();

          await toggleCommentLike(button.dataset.id);
          return;
        }

        if (action === "delete-comment") {
          event.preventDefault();
          event.stopPropagation();

          await deleteMyComment(button.dataset.id);
          return;
        }
      });
    }

  } catch (error) {
    console.error("loadVideos error:", error);

    showError("Kuzana videos byanze", error);

    feed.innerHTML =
      '<p class="empty-message">Amavideo ntiyafungutse. Gerageza kongera gufungura page.</p>';
  }
}

async function deleteVoiceForEveryone(messageId, voicePath) {
  if (!currentUser) return;
  
  const confirmed = confirm(
    "Ushaka gusiba iyi voice note kuri buri wese?"
  );
  
  if (!confirmed) return;
  
  try {
    const { data: message, error: fetchError } = await db
      .from("messages")
      .select("id, sender_id, voice_url")
      .eq("id", messageId)
      .single();
    
    if (fetchError) throw fetchError;
    
    if (message.sender_id !== currentUser.id) {
      throw new Error("Ushobora gusiba voice note wohereje gusa.");
    }
    
    // Banza usibe ubutumwa muri database.
    const { error: deleteError } = await db
      .from("messages")
      .delete()
      .eq("id", messageId)
      .eq("sender_id", currentUser.id);
    
    if (deleteError) throw deleteError;
    
    // Hanyuma usibe dosiye muri Storage.
    const { error: storageError } = await db.storage
      .from("chat-voices")
      .remove([message.voice_url || voicePath]);
    
    if (storageError) {
      console.error("Storage deletion error:", storageError);
    }
    
    showToast("Voice note yasibwe kuri buri wese.");
    
    await loadMessages();
    
  } catch (error) {
    showError("Gusiba voice note byanze", error);
  }
}


/* 13. MESSAGES: LOAD USERS */

async function loadMessageUsers() {
  const container = element("messagesUsers");

  if (!container || !currentUser) return;

  container.innerHTML =
    '<p class="empty-message">Turimo gushaka abantu...</p>';

  try {
    const { data, error } = await db
      .from("profiles")
      .select("id, full_name, bio, avatar_url")
      .neq("id", currentUser.id)
      .order("full_name", { ascending: true })
      .limit(200);

    if (error) throw error;

    const users = data || [];

    if (!users.length) {
      container.innerHTML =
        '<p class="empty-message">Nta bandi bakoresha ChatGram babonetse.</p>';
      return;
    }

    container.innerHTML = users.map(user => `
      <button
        type="button"
        class="message-user"
        data-user-id="${escapeHTML(user.id)}"
      >
        <img
          class="avatar avatar-small"
          src="${escapeHTML(avatarURL(user))}"
          alt=""
        >

        <span>${escapeHTML(user.full_name || "User")}</span>
      </button>
    `).join("");

    if (activeChatUser) {
      const activeButton = container.querySelector(
        `[data-user-id="${CSS.escape(activeChatUser.id)}"]`
      );

      if (activeButton) {
        activeButton.classList.add("active");
      }
    }
  } catch (error) {
    showError("Urutonde rw'abantu ntirwafungutse", error);

    container.innerHTML =
      '<p class="empty-message">Abantu ntibashoboye gufunguka.</p>';
  }
}


/* OPEN CHAT WITH COMMENT AUTHOR */

async function messageCommentAuthor(userId) {
  if (!currentUser) {
    showToast("Banza winjire muri konti yawe.");
    return;
  }
  
  if (!userId || userId === currentUser.id) {
    showToast("Ntushobora kwandikira konti yawe.");
    return;
  }
  
  try {
    // Shaka amakuru y'uwo ushaka kwandikira.
    const { data: profile, error } = await db
      .from("profiles")
      .select("id, full_name, avatar_url")
      .eq("id", userId)
      .single();
    
    if (error) throw error;
    
    /*
      Fungura chat ukoresheje function ya ChatGram isanzwe.
      Izina rya function riterwa n'uko chat yawe yubatswe.
    */
    
    if (typeof openChat === "function") {
      openChat(profile.id, profile.full_name || "User");
      return;
    }
    
    if (typeof openConversation === "function") {
      openConversation(profile.id);
      return;
    }
    
    showToast(
      "Umuntu yabonetse, ariko dukeneye guhuza iyi button na function ya chat yawe."
    );
    
  } catch (error) {
    console.error("Gufungura chat byanze:", error);
    showError("Ntibyashobotse gufungura chat", error);
  }
}

/* 14. MESSAGES: OPEN CHAT */

async function openChat(userId) {
  if (!currentUser) {
    showToast("Banza winjire muri konti yawe.");
    return;
  }
  
  if (!userId || userId === currentUser.id) {
    showToast("Hitamo undi muntu ushaka kwandikira.");
    return;
  }
  
  try {
    const { data: user, error } = await db
      .from("profiles")
      .select("id, full_name, bio, avatar_url")
      .eq("id", userId)
      .single();
    
    if (error) throw error;
    
    if (!user) {
      showToast("Uyu muntu ntiyabonetse.");
      return;
    }
    
    activeChatUser = user;
    
    // Update chat header.
    const header = element("messagesHeader");
    
    if (header) {
      header.textContent =
        `Uganira na ${user.full_name || "User"}`;
    }
    
    // Mark selected conversation.
    $$(".message-user").forEach(button => {
      button.classList.toggle(
        "active",
        button.dataset.userId === user.id
      );
    });
    
    // Attempt to open Messages screen using existing navigation.
    const messagesButton = document.querySelector(
      '[data-screen="messages"], [data-page="messages"], #messagesNav'
    );
    
    if (messagesButton) {
      messagesButton.click();
    }
    
    // Load the selected conversation.
    await loadMessages();
    
    startMessagePolling();
    
  } catch (error) {
    console.error("openChat error:", error);
    showError("Gufungura ikiganiro byanze", error);
  }
}
async function messageCommentAuthor(userId) {
  if (!currentUser) {
    showToast("Banza winjire muri konti yawe.");
    return;
  }
  
  if (!userId || userId === currentUser.id) {
    showToast("Ntushobora kwandikira konti yawe.");
    return;
  }
  
  await openChat(userId);
}

async function deleteMessageForEveryone(messageId) {
  if (!currentUser || !messageId) {
    showToast("Ntibyashobotse kubona ubutumwa.");
    return;
  }
  
  const confirmed = confirm(
    "Urashaka gusiba ubu butumwa ku bantu bose?"
  );
  
  if (!confirmed) return;
  
  try {
    const { data, error } = await db
      .from("messages")
      .delete()
      .eq("id", messageId)
      .eq("sender_id", currentUser.id)
      .select("id");
    
    if (error) {
      console.error("Delete error:", error);
      showToast("Gusiba byanze: " + error.message);
      return;
    }
    
    if (!data || data.length === 0) {
      showToast("Ubutumwa ntibusibwe. Reba uburenganzira bwa Supabase.");
      return;
    }
    
    showToast("Ubutumwa busibwe ku bantu bose!");
    
    await loadMessages();
    
  } catch (error) {
    console.error("Delete error:", error);
    showToast("Habaye ikibazo mu gusiba ubutumwa.");
  }
}


/* 15. MESSAGES: LOAD CONVERSATION */
async function loadMessages() {
  const container = element("messagesList");
  
  if (!container || !currentUser || !activeChatUser) return;
  
  try {
    const { data, error } = await db
      .from("messages")
      .select("*")
      .or(
        `and(sender_id.eq.${currentUser.id},receiver_id.eq.${activeChatUser.id}),and(sender_id.eq.${activeChatUser.id},receiver_id.eq.${currentUser.id})`
      )
      .order("created_at", { ascending: true })
      .limit(300);
    
    if (error) throw error;
    
    loadedMessages = data || [];
    
    // SHYIRA UBUTUMWA BWAKIRIWE KURI SEEN
    const unreadIds = loadedMessages
      .filter(
        (message) =>
        message.receiver_id === currentUser.id &&
        message.is_read === false
      )
      .map((message) => message.id);
    
    if (unreadIds.length > 0) {
      const readTime = new Date().toISOString();
      
      const { error: readError } = await db
        .from("messages")
        .update({
          is_read: true,
          read_at: readTime
        })
        .in("id", unreadIds)
        .eq("receiver_id", currentUser.id);
      
      if (readError) {
        console.error("Seen update error:", readError);
      } else {
        const unreadSet = new Set(unreadIds);
        
        loadedMessages = loadedMessages.map((message) =>
          unreadSet.has(message.id) ?
          {
            ...message,
            is_read: true,
            read_at: readTime
          } :
          message
        );
      }
    }
    
    if (!loadedMessages.length) {
      container.innerHTML =
        '<p class="empty-message">Nta butumwa burimo. Ba uwa mbere bwohereza ubutumwa!</p>';
      return;
    }
    
    const renderedMessages = await Promise.all(
      loadedMessages.map(async (message) => {
        const mine = message.sender_id === currentUser.id;
        
        let mediaHTML = "";
        
        // VOICE NOTE
        if (message.voice_url) {
          const audioURL = await getChatFileURL(
            "chat-voices",
            message.voice_url
          );
          
          mediaHTML = audioURL ?
            `
              <div class="chat-voice-note">
                <span>🎙️ Voice note</span>
                <audio controls preload="metadata">
                  <source src="${escapeHTML(audioURL)}">
                </audio>
              </div>
            ` :
            `<p>⚠️ Amajwi ntiyafungutse.</p>`;
        }
        
        // IMAGE
        if (message.image_url) {
          const imageURL = await getChatFileURL(
            "chat-images",
            message.image_url
          );
          
          mediaHTML = imageURL ?
            `
              <div class="chat-image-container">
                <a
                  href="${escapeHTML(imageURL)}"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <img
                    class="chat-image"
                    src="${escapeHTML(imageURL)}"
                    alt="Ifoto yoherejwe"
                    loading="lazy"
                  >
                </a>
              </div>
            ` :
            `<p class="media-error">⚠️ Ifoto ntiyafungutse.</p>`;
        }
        
        // DOCUMENT
        if (message.file_url) {
          const fileURL = await getChatFileURL(
            "chat-documents",
            message.file_url
          );
          
          mediaHTML = fileURL ?
            `
              <a
                href="${escapeHTML(fileURL)}"
                target="_blank"
                rel="noopener noreferrer"
              >
                📄 ${escapeHTML(message.file_name || "Fungura document")}
              </a>
            ` :
            `<p>⚠️ Document ntiyafungutse.</p>`;
        }
        
        return `
          <div class="message-bubble ${mine ? "sent" : "received"}">

            ${
              message.message_text
                ? `<p>${escapeHTML(message.message_text)}</p>`
                : ""
            }

            ${mediaHTML}

            ${
              mine
                ? `
                  <button
                    type="button"
                    class="delete-for-everyone-btn"
                    data-message-id="${escapeHTML(message.id)}"
                    title="Siba ubu butumwa ku bantu bose"
                    aria-label="Siba ubu butumwa ku bantu bose"
                  >
                     delete
                  </button>
                `
                : ""
            }

            <small class="message-meta">
              <span>${escapeHTML(formatDate(message.created_at))}</span>

              ${
                mine
                  ? message.is_read
                    ? `<span class="message-status seen">✓✓ Seen</span>`
                    : `<span class="message-status sent">✓ Sent</span>`
                  : ""
              }
            </small>

          </div>
        `;
      })
    );
    
    container.innerHTML = renderedMessages.join("");
    
    const distanceFromBottom =
      container.scrollHeight -
      container.scrollTop -
      container.clientHeight;
    
    if (distanceFromBottom < 150) {
      container.scrollTop = container.scrollHeight;
    }
  } catch (error) {
    console.error("loadMessages error:", error);
    
    showError("Ubutumwa ntibwafungutse", error);
    
    container.innerHTML =
      '<p class="empty-message">Ubutumwa ntibwafungutse. Reba internet cyangwa Supabase policies.</p>';
  }
}
/* ==========================================
   CHATGRAM — IMAGE, VOICE & DOCUMENT MESSAGES
   ========================================== */

const CHAT_FILE_BUCKETS = {
  image: "chat-images",
  voice: "chat-voices",
  document: "chat-documents"
};

const MAX_CHAT_FILE_SIZE = 15 * 1024 * 1024; // 15 MB

let voiceRecorder = null;
let voiceChunks = [];
let voiceStream = null;
let isUploadingChatFile = false;


/* 1. UPLOAD FILE TO SUPABASE */

async function uploadChatFile(file, type) {
  if (!currentUser || !activeChatUser) {
    throw new Error("Banza uhitemo umuntu uganiriza.");
  }

  const bucket = CHAT_FILE_BUCKETS[type];

  if (!bucket) {
    throw new Error("Ubwoko bwa file ntibuzwi.");
  }

  if (!file || !file.size) {
    throw new Error("Nta file wahisemo.");
  }

  if (file.size > MAX_CHAT_FILE_SIZE) {
    throw new Error("File igomba kuba itarengeje 15 MB.");
  }

  const safeName = file.name
    ? file.name.replace(/[^a-zA-Z0-9._-]/g, "_")
    : `${type}.webm`;

  const path =
    `${currentUser.id}/${Date.now()}_${safeName}`;

  const { error: uploadError } = await db.storage
    .from(bucket)
    .upload(path, file, {
      upsert: false,
      contentType: file.type || "application/octet-stream"
    });

  if (uploadError) throw uploadError;

  let message = {
    sender_id: currentUser.id,
    receiver_id: activeChatUser.id,
    message_text: "",
    is_read: false
  };

  if (type === "image") {
    message.image_url = path;
  }

  if (type === "voice") {
  message.voice_url = path;
  message.message_text = "🎙️ Voice note";
}

  if (type === "document") {
    message.file_url = path;
    message.file_name = safeName;
    message.file_type = file.type || "application/octet-stream";
  }

  const { error: insertError } = await db
    .from("messages")
    .insert(message);

  if (insertError) {
    console.error("Message insert error:", insertError);
    throw new Error(
      "File yoherejwe, ariko ubutumwa ntibwabitswe: " +
      insertError.message
    );
  }

  await loadMessages();

  showToast("File yawe yoherejwe neza!");
}




/* 2. HANDLE IMAGE SELECTION */

async function handleImageSelection(event) {
  const file = event.target.files?.[0];

  if (!file) return;

  try {
    if (!file.type.startsWith("image/")) {
      throw new Error("Hitamo ifoto yemewe.");
    }

    isUploadingChatFile = true;
    showToast("Turimo kohereza ifoto...");

    await uploadChatFile(file, "image");
  } catch (error) {
    showError("Kohereza ifoto byanze", error);
  } finally {
    isUploadingChatFile = false;
    event.target.value = "";
  }
}



/* 3. HANDLE DOCUMENT SELECTION */

async function handleDocumentSelection(event) {
  const file = event.target.files?.[0];

  if (!file) return;

  try {
    const allowedExtensions =
      /\.(pdf|doc|docx|xls|xlsx|ppt|pptx|txt|csv|odt|ods)$/i;

    if (!allowedExtensions.test(file.name)) {
      throw new Error("Iyo document ntiremewe.");
    }

    isUploadingChatFile = true;
    showToast("Turimo kohereza document...");

    await uploadChatFile(file, "document");
  } catch (error) {
    showError("Kohereza document byanze", error);
  } finally {
    isUploadingChatFile = false;
    event.target.value = "";
  }
}


/* 4. START VOICE RECORDING */

async function startVoiceRecording() {
  if (!currentUser || !activeChatUser) {
    showToast("Banza uhitemo umuntu uganiriza.");
    return;
  }

  if (!navigator.mediaDevices?.getUserMedia ||
      typeof MediaRecorder === "undefined") {
    showToast(
      "Telefoni cyangwa browser yawe ntishyigikira gufata amajwi."
    );
    return;
  }

  try {
    voiceStream = await navigator.mediaDevices.getUserMedia({
      audio: true
    });

    voiceChunks = [];

    let options = {};

    if (MediaRecorder.isTypeSupported("audio/webm;codecs=opus")) {
      options.mimeType = "audio/webm;codecs=opus";
    } else if (MediaRecorder.isTypeSupported("audio/webm")) {
      options.mimeType = "audio/webm";
    }

    voiceRecorder = new MediaRecorder(voiceStream, options);

    voiceRecorder.ondataavailable = event => {
      if (event.data && event.data.size > 0) {
        voiceChunks.push(event.data);
      }
    };

    voiceRecorder.onstop = async () => {
      try {
        const mimeType =
          voiceRecorder?.mimeType || "audio/webm";

        const audioBlob = new Blob(voiceChunks, {
          type: mimeType
        });

        if (!audioBlob.size) {
          throw new Error("Nta majwi yafashwe.");
        }

        const extension = mimeType.includes("ogg")
          ? "ogg"
          : mimeType.includes("mp4")
            ? "m4a"
            : "webm";

        const audioFile = new File(
          [audioBlob],
          `voice-${Date.now()}.${extension}`,
          { type: mimeType }
        );

        isUploadingChatFile = true;

        showToast("Turimo kohereza amajwi...");

        await uploadChatFile(audioFile, "voice");
      } catch (error) {
        showError("Kohereza amajwi byanze", error);
      } finally {
        isUploadingChatFile = false;

        if (voiceStream) {
          voiceStream.getTracks().forEach(track => track.stop());
          voiceStream = null;
        }

        voiceRecorder = null;
        voiceChunks = [];

        const startButton = element("recordVoiceBtn");
        const stopButton = element("stopVoiceBtn");

        if (startButton) startButton.hidden = false;
        if (stopButton) stopButton.hidden = true;

        setStatus("voiceStatus", "");
      }
    };

    voiceRecorder.start();

    const startButton = element("recordVoiceBtn");
    const stopButton = element("stopVoiceBtn");

    if (startButton) startButton.hidden = true;
    if (stopButton) stopButton.hidden = false;

    setStatus("voiceStatus", "🔴 Turimo gufata amajwi...");
  } catch (error) {
    if (voiceStream) {
      voiceStream.getTracks().forEach(track => track.stop());
      voiceStream = null;
    }

    showError("Gufata amajwi byanze", error);
  }
}


/* 5. STOP VOICE RECORDING */

function stopVoiceRecording() {
  if (voiceRecorder &&
      voiceRecorder.state !== "inactive") {
    voiceRecorder.stop();
  }
}


/* 6. CREATE TEMPORARY URL FOR PRIVATE FILES */
async function getChatFileURL(bucket, path) {
  if (!path) {
    console.error("Chat file path irimo ubusa.");
    return "";
  }
  
  try {
    // Niba ari URL yuzuye, yisubize uko iri.
    if (/^https?:\/\//i.test(path)) {
      return path;
    }
    
    // Kuraho slash zidakenewe ku ntangiriro.
    const cleanPath = String(path).replace(/^\/+/, "");
    
    const { data, error } = await db.storage
      .from(bucket)
      .createSignedUrl(cleanPath, 3600);
    
    if (error) {
      console.error("Chat file signed URL error:", {
        bucket,
        path: cleanPath,
        message: error.message
      });
      
      return "";
    }
    
    if (!data?.signedUrl) {
      console.error("Supabase ntiyagaruye signed URL:", {
        bucket,
        path: cleanPath
      });
      
      return "";
    }
    
    return data.signedUrl;
    
  } catch (error) {
    console.error("getChatFileURL error:", error);
    return "";
  }
}

/* 7. OPEN DOCUMENT */

async function openChatDocument(bucket, path) {
  try {
    const url = await getChatFileURL(bucket, path);

    if (!url) {
      throw new Error(
        "Document ntifungutse. Reba bucket permissions."
      );
    }

    window.open(url, "_blank", "noopener,noreferrer");
  } catch (error) {
    showError("Gufungura document byanze", error);
  }
}


/* 16. MESSAGES: SEND */

async function sendMessage(event) {
  event.preventDefault();

  if (!currentUser) return;

  if (!activeChatUser) {
    showToast("Banza uhitemo umuntu uganiriza.");
    return;
  }

  const input = element("messageInput");
  const text = input?.value.trim();

  if (!text) return;

  const button = element("messageForm")
    ?.querySelector('button[type="submit"]');

  setButtonLoading(button, true, "Ohereza...");

  try {
    const message = {
      sender_id: currentUser.id,
      receiver_id: activeChatUser.id,
      message_text: text,
      is_read: false
    };

    const { error } = await db
      .from("messages")
      .insert(message);

    if (error) throw error;

    input.value = "";

    await loadMessages();

  } catch (error) {
    showError("Ubutumwa ntibwoherejwe", error);
  } finally {
    setButtonLoading(button, false);

    if (input) input.focus();
  }
}


/* 17. MESSAGE REFRESH - DISABLED */

function startMessagePolling() {
  stopMessagePolling();
}

function stopMessagePolling() {
  if (messagePolling) {
    clearInterval(messagePolling);
    messagePolling = null;
  }
}

/* 18. SEARCH USERS */

function searchUsers() {
  const query = element("userSearch")?.value
    .trim()
    .toLowerCase() || "";

  $$(".message-user").forEach(button => {
    const name = button.textContent.toLowerCase();

    button.hidden = !name.includes(query);
  });
}


/* 19. ENTER APPLICATION */

async function enterApp() {
  if (!currentUser) {
    showAuthScreen();
    return;
  }

  try {
    await ensureProfile();

    showMainApp();

    await loadProfile();

    await loadVideos();

    showPage("home");
  } catch (error) {
    showError("Gufungura ChatGram byanze", error);
    showMainApp();
    showPage("home");
  }
}

/* CHATGRAM — SUBMIT COMMENT WITHOUT FEED REFRESH */

async function submitComment(event) {
  event.preventDefault();
  event.stopPropagation();
  
  if (!currentUser) {
    showToast("Banza winjire muri konti yawe.");
    return;
  }
  
  const form = event.target;
  
  if (!form.matches(".comment-form")) return;
  
  const videoId = form.dataset.videoId;
  const input = form.querySelector('[name="comment_text"]');
  const commentText = input?.value.trim();
  
  if (!videoId || !commentText) return;
  
  const button = form.querySelector('button[type="submit"]');
  
  if (button?.disabled) return;
  
  if (button) button.disabled = true;
  
  try {
    const { data, error } = await db
      .from("video_comments")
      .insert({
        video_id: videoId,
        user_id: currentUser.id,
        comment_text: commentText
      })
      .select("id, video_id, user_id, comment_text, created_at")
      .single();
    
    if (error) throw error;
    
    // Ongeramo comment nshya kuri screen, nta refresh.
    const commentsList = form
      .closest(".video-comments")
      ?.querySelector(".comments-list");
    
    if (commentsList && data) {
      const emptyMessage =
        commentsList.querySelector(".empty-message");
      
      if (emptyMessage) emptyMessage.remove();
      
      const item = document.createElement("div");
      item.className = "comment-item";
      item.dataset.commentId = data.id;
      
      const content = document.createElement("div");
      content.className = "comment-content";
      
      const author = document.createElement("strong");
      author.textContent =
        currentUser.user_metadata?.full_name || "Wowe";
      
      const text = document.createElement("span");
      text.textContent = data.comment_text;
      
      content.append(author, text);
      item.append(content);
      
      commentsList.append(item);
    }
    
    input.value = "";
    showToast("Comment yawe yoherejwe!");
    
  } catch (error) {
    console.error("Comment error:", error);
    showError("Comment ntiyoherejwe", error);
  } finally {
    if (button) button.disabled = false;
  }
}



/* 20. EVENT LISTENERS */

function setupEventListeners() {

  /* Authentication forms */

  element("loginForm")?.addEventListener("submit", signIn);

  element("signupForm")?.addEventListener("submit", signUp);


element("messagesList")?.addEventListener("click", (event) => {
  const button = event.target.closest(".delete-voice-btn");
  
  if (!button) return;
  
  deleteVoiceForEveryone(
    button.dataset.messageId,
    button.dataset.voicePath
  );
});

element("imageInput")?.addEventListener(
  "change",
  handleImageSelection
);

element("messagesList")?.addEventListener("click", async (event) => {
  const button = event.target.closest(
    ".delete-for-everyone-btn"
  );
  
  if (!button) return;
  
  event.preventDefault();
  event.stopPropagation();
  
  await deleteMessageForEveryone(
    button.dataset.messageId
  );
});

  /* Login and signup switch */

  $$("[data-show-signup]").forEach(button => {
    button.addEventListener("click", () => {
      element("loginForm").hidden = true;
      element("signupForm").hidden = false;
    });
  });

  $$("[data-show-login]").forEach(button => {
    button.addEventListener("click", () => {
      element("signupForm").hidden = true;
      element("loginForm").hidden = false;
    });
  });

  /* Navigation */

  $$("[data-page]").forEach(button => {
    button.addEventListener("click", () => {
      showPage(button.dataset.page);
    });
  });

  /* Logout */

  element("logoutBtn")?.addEventListener("click", signOut);

  /* Profile */

  $$('[data-action="save-profile"]').forEach(button => {
    button.addEventListener("click", saveProfile);
  });

  element("avatarInput")?.addEventListener("change", uploadAvatar);

  /* Video upload */

  element("videoUploadForm")?.addEventListener(
    "submit",
    uploadVideo
  );

  setupVideoPreview();
  
    /* Delete my own videos */
  
  element("profileVideos")?.addEventListener(
    "click",
    async event => {
      const button = event.target.closest(
        "[data-delete-video]"
      );
      
      if (!button) return;
      
      await deleteMyVideo(button.dataset.deleteVideo);
    }
  );

  /* Feed actions */

  element("videosFeed")?.addEventListener("click", async event => {
    const button = event.target.closest("[data-action]");

    if (!button) return;

    const action = button.dataset.action;
    const id = button.dataset.id;

    if (action === "like") {
      await toggleLike(id);
    }

    if (action === "share") {
      await shareVideo(id);
    }

    if (action === "toggle-comments") {
      const comments = element(`comments-${id}`);

      if (comments) {
        comments.hidden = !comments.hidden;
      }
    }
  });




  element("videosFeed")?.addEventListener(
    "submit",
    submitComment
  );

  /* Messages */
  
    /* Voice Note, Image & Document Listeners */
  
  element("recordVoiceBtn")?.addEventListener(
    "click",
    startVoiceRecording
  );
  
  element("stopVoiceBtn")?.addEventListener(
    "click",
    stopVoiceRecording
  );
  
  element("imageInput")?.addEventListener(
    "change",
    handleImageSelection
  );
  
  element("documentInput")?.addEventListener(
    "change",
    handleDocumentSelection
  );

  element("messagesUsers")?.addEventListener("click", event => {
    const button = event.target.closest("[data-user-id]");

    if (!button) return;

    openChat(button.dataset.userId);
  });

  element("messageForm")?.addEventListener(
    "submit",
    sendMessage
  );

  element("userSearch")?.addEventListener(
    "input",
    searchUsers
  );

  /* Stop polling when leaving the page */

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      stopMessagePolling();
    } else if (
      activePage === "messages" &&
      currentUser &&
      activeChatUser
    ) {
      startMessagePolling();
      loadMessages();
    }
  });
}


/* 21. START APPLICATION */

async function initializeApp() {
  setupEventListeners();

  showAuthScreen();

  try {
    const { data, error } = await db.auth.getSession();

    if (error) throw error;

    currentUser = data.session?.user || null;

    if (currentUser) {
      await enterApp();
    } else {
      showAuthScreen();
    }
  } catch (error) {
    showError("ChatGram ntiyashoboye gutangira", error);
    showAuthScreen();
  }

  db.auth.onAuthStateChange((event, session) => {
    currentUser = session?.user || null;

    if (event === "SIGNED_OUT") {
      currentProfile = null;
      activeChatUser = null;

      showAuthScreen();
    }
  });
}

// =====================================
// CHATGRAM PUSH NOTIFICATIONS SETUP
// =====================================

const CHATGRAM_VAPID_PUBLIC_KEY = "BAhxlnsibLoEJI4hnuX5y7A-vPQrLVHNk3oS-LUy_dpBPkNrtXWzFj10XeJ5Zlo9rqSYN_EPuOtQN4v5j6_5O-c";

function urlBase64ToUint8Array(base64String) {
  const padding = "=".repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/-/g, "+")
    .replace(/_/g, "/");

  const rawData = atob(base64);
  return Uint8Array.from(rawData, char => char.charCodeAt(0));
}

async function registerChatGramPush() {
  try {
    if (!("serviceWorker" in navigator)) {
      throw new Error("Iyi browser ntiyemera Service Worker.");
    }

    if (!("PushManager" in window)) {
      throw new Error("Iyi browser ntiyemera Push Notifications.");
    }

    if (!currentUser) {
      throw new Error("Banza winjire muri ChatGram.");
    }

if (!CHATGRAM_VAPID_PUBLIC_KEY ||
  CHATGRAM_VAPID_PUBLIC_KEY === "USER_PUBLIC_VAPID_KEY_HERE") {
  throw new Error("Public VAPID Key ntirashyirwamo.");
}

    const permission = await Notification.requestPermission();

    if (permission !== "granted") {
      throw new Error("Uwemereze ChatGram kukwereka notifications.");
    }

    const registration =
      await navigator.serviceWorker.register("./service-worker.js");

    await navigator.serviceWorker.ready;

    let subscription = await registration.pushManager.getSubscription();

    if (!subscription) {
      subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey:
          urlBase64ToUint8Array(CHATGRAM_VAPID_PUBLIC_KEY)
      });
    }

    const { data: sessionData, error: sessionError } =
      await db.auth.getSession();

    if (sessionError) throw sessionError;

    const accessToken = sessionData.session?.access_token;

    if (!accessToken) {
      throw new Error("Session yawe yarangiye. Ongera winjire.");
    }

    const subscriptionJSON = subscription.toJSON();

    const { error } = await db
      .from("push_subscriptions")
      .upsert({
        user_id: currentUser.id,
        endpoint: subscriptionJSON.endpoint,
        subscription: subscriptionJSON,
        updated_at: new Date().toISOString()
      }, {
        onConflict: "endpoint"
      });

    if (error) throw error;

    alert("ChatGram: Telefoni yawe yanditswe kuri notifications!");

  } catch (error) {
    console.error("ChatGram push setup:", error);
    alert("Push setup yanze: " + (error.message || "Ikosa ritazwi"));
  }
}


// CHATGRAM PUSH SETUP BUTTON
window.registerChatGramPush = registerChatGramPush;

document.addEventListener("DOMContentLoaded", () => {
  const pushButton = document.getElementById("enablePushNotifications");
  
  if (pushButton) {
    pushButton.addEventListener("click", () => {
      registerChatGramPush();
    });
  }
});



// ChatGram: ask for notifications after login
async function checkChatGramNotifications() {
  try {
    if (!currentUser) return;
    
    if (!("Notification" in window)) return;
    if (!("serviceWorker" in navigator)) return;
    if (!("PushManager" in window)) return;
    
    // User already allowed notifications: do not ask again.
    if (Notification.permission === "granted") {
      return;
    }
    
    // If the user has not decided, show our own prompt.
    if (Notification.permission === "default") {
      const enable = confirm(
        "🔔 ChatGram Notifications\n\n" +
        "Ushaka kujya ubona ubutumwa bushya n'igihe ChatGram ifunze?\n\n" +
        "Kanda OK kugira ngo ukomeze."
      );
      
      if (enable) {
        await registerChatGramPush();
      }
    }
  } catch (error) {
    console.error("ChatGram notification check:", error);
  }
}

/* RUN */

if (document.readyState === "loading") {
  document.addEventListener(
    "DOMContentLoaded",
    initializeApp,
    { once: true }
  );
} else {
  initializeApp();
}


/* DELETE MY VIDEO FROM CHATGRAM */

async function deleteMyVideo(videoId) {
  if (!currentUser || !videoId) {
    showToast("Banza winjire muri konti yawe.");
    return;
  }
  
  const confirmed = window.confirm(
    "Urashaka gusiba iyi video koko? Ntushobora kuyigarura."
  );
  
  if (!confirmed) return;
  
  try {
    const { data: video, error: findError } = await db
      .from("videos")
      .select("id, user_id, video_path")
      .eq("id", videoId)
      .eq("user_id", currentUser.id)
      .single();
    
    if (findError) throw findError;
    
    if (!video) {
      showToast("Video ntiyabonetse cyangwa si iyawe.");
      return;
    }
    
    const { error: deleteError } = await db
      .from("videos")
      .delete()
      .eq("id", videoId)
      .eq("user_id", currentUser.id);
    
    if (deleteError) throw deleteError;
    
    showToast("Video yasibwe kuri profile yawe.");
    
    await loadProfileVideos();
    await loadVideos();
    
  } catch (error) {
    console.error("Delete video error:", error);
    showError("Gusiba video byanze", error);
  }
}



/* =====================================
   CHATGRAM — DELETE MY COMMENT
===================================== */

async function deleteMyComment(commentId) {
  if (!currentUser) {
    showToast("Banza winjire muri konti yawe.");
    return;
  }
  
  if (!commentId) {
    showToast("Comment ntiyabonetse.");
    return;
  }
  
  const confirmed = window.confirm(
    "Urashaka gusiba iyi comment koko?"
  );
  
  if (!confirmed) return;
  
  try {
    const { data: comment, error: findError } = await db
      .from("video_comments")
      .select("id, user_id, video_id")
      .eq("id", commentId)
      .single();
    
    if (findError) throw findError;
    
    if (comment.user_id !== currentUser.id) {
      showToast("Ushobora gusiba comment yawe gusa.");
      return;
    }
    
    const { error: deleteError } = await db
      .from("video_comments")
      .delete()
      .eq("id", commentId)
      .eq("user_id", currentUser.id);
    
    if (deleteError) throw deleteError;
    
    const commentElement = document.querySelector(
      `.comment-item[data-comment-id="${CSS.escape(String(commentId))}"]`
    );
    
    if (commentElement) {
      commentElement.remove();
    }
    
    showToast("Comment yasibwe neza! ");
    
    await loadVideos();
    
  } catch (error) {
    console.error("Delete comment error:", error);
    showError("Gusiba comment byanze", error);
  }
}