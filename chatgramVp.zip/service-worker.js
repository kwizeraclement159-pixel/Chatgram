"use strict";

const CACHE_NAME = "chatgram-shell-v4";

const APP_FILES = [
  "./",
  "./index.html",
  "./style.css",
  "./app.js",
  "./manifest.json",
  "./libs/supabase-js@2.js"
];

const SUPABASE_SDK =
  "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2";

// INSTALL
self.addEventListener("install", event => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      
      // Cache essential local app files.
      for (const file of APP_FILES) {
        try {
          const response = await fetch(file, {
            cache: "reload"
          });
          
          if (response.ok) {
            await cache.put(file, response);
          }
        } catch (error) {
          console.warn("Could not cache app file:", file);
        }
      }
      
      // Cache the Supabase SDK if internet is available.
      try {
        const response = await fetch(SUPABASE_SDK);
        
        if (response.ok) {
          await cache.put(SUPABASE_SDK, response);
        }
      } catch (error) {
        console.warn("Supabase SDK will need internet until cached.");
      }
      
      await self.skipWaiting();
    })()
  );
});

// ACTIVATE
self.addEventListener("activate", event => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      
      await Promise.all(
        keys
        .filter(
          key =>
          key.startsWith("chatgram-shell-") &&
          key !== CACHE_NAME
        )
        .map(key => caches.delete(key))
      );
      
      await self.clients.claim();
    })()
  );
});

// FETCH
self.addEventListener("fetch", event => {
  const request = event.request;
  
  if (request.method !== "GET") return;
  
  const url = new URL(request.url);
  
  // Handle local app files and navigation.
  if (url.origin === self.location.origin) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(CACHE_NAME);
        
        try {
          const response = await fetch(request);
          
          if (response.ok) {
            const key =
              request.mode === "navigate" ?
              "./index.html" :
              request;
            
            await cache.put(key, response.clone());
          }
          
          return response;
        } catch (error) {
          const cached = await cache.match(request);
          
          if (cached) return cached;
          
          if (request.mode === "navigate") {
            const home = await cache.match("./index.html");
            
            if (home) return home;
          }
          
          return new Response(
            "ChatGram: This page is not available offline yet. Connect to the internet and reopen the app.",
            {
              status: 503,
              headers: {
                "Content-Type": "text/plain; charset=utf-8"
              }
            }
          );
        }
      })()
    );
    
    return;
  }
  
  // Cache only the Supabase SDK, not Supabase API responses.
  if (url.href === SUPABASE_SDK) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(CACHE_NAME);
        
        try {
          const response = await fetch(request);
          
          if (response.ok) {
            await cache.put(SUPABASE_SDK, response.clone());
          }
          
          return response;
        } catch (error) {
          const cached = await cache.match(SUPABASE_SDK);
          
          if (cached) return cached;
          
          return new Response("Supabase SDK unavailable offline.", {
            status: 503,
            headers: {
              "Content-Type": "text/plain; charset=utf-8"
            }
          });
        }
      })()
    );
  }
});

// =====================================
// CHATGRAM PUSH NOTIFICATIONS
// =====================================

self.addEventListener("push", event => {
  let data = {};
  
  try {
    data = event.data ? event.data.json() : {};
  } catch (error) {
    data = {
      title: "ChatGram",
      body: event.data ? event.data.text() : "Ufite ubutumwa bushya."
    };
  }
  
  const title = data.title || "ChatGram — C's Fame";
  const options = {
    body: data.body || "Ufite ubutumwa bushya.",
    icon: "./icons/icon-192.png",
    badge: "./icons/icon-192.png",
    tag: data.tag || "chatgram-message",
    data: {
      url: data.url || "./",
      senderId: data.senderId || null
    }
  };
  
  event.waitUntil(
    self.registration.showNotification(title, options)
  );
});

self.addEventListener("notificationclick", event => {
  event.notification.close();
  
  const data = event.notification.data || {};
  const targetUrl = new URL(data.url || "./", self.location.origin).href;
  
  event.waitUntil(
    (async () => {
      const windows = await self.clients.matchAll({
        type: "window",
        includeUncontrolled: true
      });
      
      for (const client of windows) {
        if ("focus" in client) {
          await client.focus();
          
          if (data.senderId && "postMessage" in client) {
            client.postMessage({
              type: "CHATGRAM_OPEN_CHAT",
              senderId: data.senderId
            });
          }
          
          return;
        }
      }
      
      await self.clients.openWindow(targetUrl);
    })()
  );
});